package com.megafreeapps.speedometer.live.camera.speed.detector.freegps.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.R;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.modle.MapItem;

import java.util.ArrayList;

public class MapTypeAdapter extends ArrayAdapter<MapItem> {
    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        return initView(position, convertView, parent);
    }

    @Override
    public View getDropDownView(int position, View convertView, @NonNull ViewGroup parent) {
        return initView(position, convertView, parent);
    }

    public MapTypeAdapter(Context context, ArrayList<MapItem> mapTypeList) {
        super(context, 0, mapTypeList);

    }

    private View initView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext())
                    .inflate(R.layout.map_type_spinner_item, parent, false);
        }
        ImageView imageViewMapType = convertView.findViewById(R.id.iv_map_type);
        TextView textViewMapName = convertView.findViewById(R.id.tv_map_name);

        MapItem currentItem = getItem(position);

        if (currentItem != null) {
            imageViewMapType.setImageResource(currentItem.getmMapImage());
            textViewMapName.setText(currentItem.getmMapName());
        }
        return convertView;
    }
}
