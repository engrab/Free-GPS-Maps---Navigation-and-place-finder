package com.megafreeapps.speedometer.live.camera.speed.detector.freegps.modle;

public class UnitItem {
    private String unit;

    public String getUnit() {
        return unit;
    }

    public UnitItem(String unit) {
        this.unit = unit;
    }
}
