package com.megafreeapps.speedometer.live.camera.speed.detector.freegps.activities;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.os.SystemClock;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.TaskStackBuilder;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.model.LatLng;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.AppController;

import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.R;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.adapters.UnitTypeAdapter;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.modle.UnitItem;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.util.DigitalTextView;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.util.PurchasePref;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

public class DigitalSpeedoMeterActivity extends AppCompatActivity {
    private ArrayList<UnitItem> mUnitItemList;

    private static final String[] unit = {"km/h", "mph", "meter/sec", "knots"};
    Activity context;
    AdView mAdView;
    Chronometer durationTV;

    private TextView tvSpeed, tvUnit, tvLat, tvLon, tvAccuracy, tvHeading, tvMaxSpeed, accuracy, speedLimit, latlong, tvMaximumSpeed, unitText, direction ;
    private int unitType;
    private NotificationCompat.Builder mbuilder;
    private NotificationManager mnotice;
    private double maxSpeed = -100.0;
    public static int maximumSpeed = 0;
    TextView Speed_Limt;
    long elapsedSeconds, minutes, seconds, hours, elapsedTime;

    boolean isFromStart = true;
    Geocoder geocoder;

    private SharedPreferences prefs;
    Dialog mDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_digital_speedo_meter);
        context = DigitalSpeedoMeterActivity.this;

//        initList();

        Init();


        durationTV.setBase(SystemClock.elapsedRealtime()+elapsedTime);
        durationTV.start();
        durationTV.setText("00:00:00");
        durationTV.setOnChronometerTickListener(new Chronometer.OnChronometerTickListener() {
            @Override
            public void onChronometerTick(Chronometer chronometer) {


                    elapsedSeconds++;

                    long time = SystemClock.elapsedRealtime() - chronometer.getBase();
                    int h   = (int)(time /3600000);
                    int m = (int)(time - h*3600000)/60000;
                    int s= (int)(time - h*3600000- m*60000)/1000 ;
                    String t = (h < 10 ? "0"+h: h)+":"+(m < 10 ? "0"+m: m)+":"+ (s < 10 ? "0"+s: s);
                    chronometer.setText(t);


            }
        });



//        Spinner spinnerUnitType = findViewById(R.id.sp_unit_type);
//        UnitTypeAdapter mUnitTypeAdapter = new UnitTypeAdapter(this, mUnitItemList);
//        spinnerUnitType.setAdapter(mUnitTypeAdapter);
//
//        spinnerUnitType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//
//                UnitItem clickedItem = (UnitItem) parent.getItemAtPosition(position);
//                String clickedUnitTypeName = clickedItem.getUnit();
////                int clickedMapTypeId = clickedItem.getmMapImage();
////                Toast.makeText(context, clickedMapTypeName+" selelcted", Toast.LENGTH_SHORT).show();
////                Toast.makeText(context, clickedMapTypeId+"", Toast.LENGTH_SHORT).show();
//
//
//                switch (clickedUnitTypeName) {
//
//
//                    case "km/h":
//                        Toast.makeText(getApplicationContext(), "", Toast.LENGTH_SHORT).show();
//                        break;
//                    case "mph":
//                        Toast.makeText(getApplicationContext(), "", Toast.LENGTH_SHORT).show();
//                        break;
//                    case "m/s":
//                        Toast.makeText(getApplicationContext(), "", Toast.LENGTH_SHORT).show();
//                        break;
//                    case "knots":
//                        Toast.makeText(getApplicationContext(), "", Toast.LENGTH_SHORT).show();
//                        break;
//                }
//
//            }
//
//            @Override
//            public void onNothingSelected(AdapterView<?> parent) {
//
//            }
//        });

        PurchasePref purchasePref = new PurchasePref(getApplicationContext());
        if (purchasePref.getItemDetail().equals("") && purchasePref.getProductId().equals("")) {
            mAdView = findViewById(R.id.adView);
            mAdView.loadAd(new AdRequest.Builder().build());
            mAdView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                    super.onAdLoaded();
                    mAdView.setVisibility(View.VISIBLE);
                }
            });
        }
        if (savedInstanceState != null) {
            maxSpeed = savedInstanceState.getDouble("maxspeed", -100.0);

        }


    }

    private void initList() {
        mUnitItemList = new ArrayList<>();
        mUnitItemList.add(new UnitItem("Km/h"));
        mUnitItemList.add(new UnitItem("mph"));
        mUnitItemList.add(new UnitItem("m/s"));
        mUnitItemList.add(new UnitItem("knots"));
    }

    @SuppressLint({"SetJavaScriptEnabled", "ClickableViewAccessibility"})
    private void Init() {

        Typeface font = Typeface.createFromAsset(context.getAssets(), "franklingothic.ttf");

        tvSpeed = findViewById(R.id.tvSpeed);
        tvSpeed.setTypeface(font);
        tvMaxSpeed = findViewById(R.id.tvMaxSpeed);
        tvMaxSpeed.setTypeface(font);
        tvUnit = findViewById(R.id.tvUnitc);
        tvLat = findViewById(R.id.tvLat);
        tvLat.setTypeface(font);
        tvLon = findViewById(R.id.tvLon);
        tvLon.setTypeface(font);
        tvAccuracy = findViewById(R.id.tvAccuracy);
        accuracy = findViewById(R.id.tv_accuracy);
        accuracy.setTypeface(font);
        tvAccuracy.setTypeface(font);
        tvHeading = findViewById(R.id.tvHeading);
        tvHeading.setTypeface(font);
//        Speed_Limt = findViewById(R.id.tv_speed_limit);
//        Speed_Limt.setTypeface(font);
        speedLimit = findViewById(R.id.tv_speed_limit_text);
        speedLimit.setTypeface(font);
        latlong = findViewById(R.id.tv_lat_long);
        latlong.setTypeface(font);
        tvMaximumSpeed = findViewById(R.id.tv_max_speed);
        tvMaximumSpeed.setTypeface(font);
        unitText = findViewById(R.id.tv_unit);
        unitText.setTypeface(font);
        direction = findViewById(R.id.tv_direction);
        direction.setTypeface(font);

        durationTV = findViewById(R.id.durationtvz);



        //for handling notification
        mbuilder = new NotificationCompat.Builder(context, "ChannelID115");
        mnotice = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        prefs = PreferenceManager.getDefaultSharedPreferences(context);

        unitType = Integer.parseInt(prefs.getString("unit", "1"));
        tvUnit.setText(unit[unitType - 1]);


        if (!this.isLocationEnabled(context)) {


            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle(R.string.gps_not_found_title);  // GPS not found
            builder.setMessage(R.string.gps_not_found_message); // Want to enable?
            builder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {

                    Intent intent = new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                    context.startActivity(intent);
                }
            });

            //if no - bring user to selecting Static Location Activity
            builder.setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Toast.makeText(context, "Please enable Location-based service / GPS", Toast.LENGTH_LONG).show();


                }


            });
            builder.create().show();


        }

        geocoder = new Geocoder(this, Locale.getDefault());



        PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
        if (pm != null) {
            PowerManager.WakeLock wakeLock = pm.newWakeLock(
                    PowerManager.SCREEN_DIM_WAKE_LOCK, "My wakelook");
        }

        context.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);


        new SpeedTask().execute("string");


        unitText.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                startActivity(new Intent(DigitalSpeedoMeterActivity.this, SettingsActivity.class));
                return false;
            }


        });

//        findViewById(R.id.ll_speed_limit).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                isFromStart = false;
//                showSpeedDialog();
//
//            }
//        });
//        Speed_Limt.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                isFromStart = false;
//                showSpeedDialog();
//            }
//        });


    }

    private void showSpeedDialog() {
        try {
            View view = LayoutInflater.from(DigitalSpeedoMeterActivity.this).inflate(R.layout.speedlimit_dialog, null, false);
            final EditText speedLimit = view.findViewById(R.id.speed_limit);
            speedLimit.setText(maxSpeed + "");
            speedLimit.setSelection(speedLimit.length());
//            speedLimit.setSelected(true);
//            speedLimit.setSelectAllOnFocus(true);
            view.findViewById(R.id.go).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (speedLimit.getText().toString().equals("")) {
                        Toast.makeText(DigitalSpeedoMeterActivity.this, "Please enter speedometer limit", Toast.LENGTH_SHORT).show();
                    } else {
                        try {
                            maximumSpeed = Integer.parseInt(speedLimit.getText().toString());
                        } catch (Exception e) {
                            String speed = speedLimit.getText().toString();
                            if (speed.contains(".")) {
                                speed = speed.substring(0, speed.indexOf(".") - 1);
                            }
                            maximumSpeed = Integer.parseInt(speed);
                        }
                        SharedPreferences.Editor editor = prefs.edit();
                        editor.putInt("maxSpeed", maximumSpeed);
                        editor.apply();
                        Speed_Limt.setText(maximumSpeed +"");
                        mDialog.dismiss();
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                            if (isFromStart && !Objects.requireNonNull(prefs.getString("address", "")).equals("")) {
                                showLoadPreviousDialog(prefs.getString("address", ""));
                            }
                        }
                    }
                }
            });

            mDialog = new Dialog(DigitalSpeedoMeterActivity.this, R.style.MaterialDialogSheet);
            mDialog.setContentView(view);
            mDialog.setCancelable(true);
            mDialog.setCanceledOnTouchOutside(false);
            if (mDialog.getWindow() != null) {
                mDialog.getWindow().setLayout(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                mDialog.getWindow().setGravity(Gravity.CENTER);
            }
            mDialog.show();
        } catch (Exception ignored) {
        }
    }

    private void showLoadPreviousDialog(final String destination) {
        try {
            View view = LayoutInflater.from(DigitalSpeedoMeterActivity.this).inflate(R.layout.showloadprevous_dialog, null, false);
            final TextView tvDestination = view.findViewById(R.id.tvMessage);
            tvDestination.setText("Destination: " + destination);
            view.findViewById(R.id.btnload).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mDialog.dismiss();
                    setLatLng(destination);
                }
            });
            view.findViewById(R.id.btncancel).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mDialog.dismiss();

                }
            });

            mDialog = new Dialog(DigitalSpeedoMeterActivity.this, R.style.MaterialDialogSheet);
            mDialog.setContentView(view);
            mDialog.setCancelable(true);
            mDialog.setCanceledOnTouchOutside(false);
            if (mDialog.getWindow() != null) {
                mDialog.getWindow().setLayout(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                mDialog.getWindow().setGravity(Gravity.CENTER);
            }
            mDialog.show();
        } catch (Exception ignored) {
        }
    }

    private void setLatLng(String address) {
        try {
            if (address == null || address.equals("")) {
                Toast.makeText(this, "Address not found\nPlease Try Again", Toast.LENGTH_SHORT).show();
                return;
            }
            try {
                List<Address> addresses = geocoder.getFromLocationName(address, 1);
                if (addresses != null) {

                    Address locationAddress = addresses.get(0);
                    if (AppController.getAppInstance().getGlobalLocation() == null) {
                        Toast.makeText(this, "Starting point not found", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (locationAddress == null) {
                        Toast.makeText(this, "Address not found\nPlease Try Again", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    SharedPreferences.Editor editor = prefs.edit();
                    editor.putString("address", address);
                    editor.apply();
                    Location location = AppController.getAppInstance().getGlobalLocation();
                    LatLng orign = new LatLng(location.getLatitude(), location.getLongitude());

                    LatLng dest = new LatLng(locationAddress.getLatitude(), locationAddress.getLongitude());

                } else {
                    Toast.makeText(this, "Address not found\nPlease Try Again", Toast.LENGTH_SHORT).show();
                    Log.w("", "My Current loction address,No Address returned!");
                }
            } catch (Exception e) {
                e.printStackTrace();
                Log.w("", "My Current loction address,Canont get Address!");
            }

        } catch (Exception ignored) {

        }
    }



    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putDouble("maxspeed", maxSpeed);
    }

    @Override
    public void onResume() {
        super.onResume();
        if (mAdView != null) {
            mAdView.resume();
        }
        prefs = PreferenceManager.getDefaultSharedPreferences(context);
        unitType = Integer.parseInt(prefs.getString("unit", "1"));
        maxSpeed = prefs.getFloat("maxspeed", -100.0f);


        tvUnit.setText(unit[unitType - 1]);

        if (maxSpeed > 0) {

            float multiplier = 3.6f;

            switch (unitType) {
                case 1:
                    multiplier = 3.6f;
                    break;
                case 2:
                    multiplier = 2.25f;
                    break;
                case 3:
                    multiplier = 1.0f;
                    break;

                case 4:
                    multiplier = 1.943856f;
                    break;

            }
            NumberFormat numberFormat = NumberFormat.getNumberInstance();
            numberFormat.setMaximumFractionDigits(0);

            tvMaxSpeed.setText(numberFormat.format(maxSpeed * multiplier));
        }
        removeNotification();
    }

    @Override
    public void onStop() {
        super.onStop();
        displayNotification();
    }

    @Override
    public void onPause() {
        super.onPause();
        try {
            if (mAdView != null) {
                mAdView.pause();
            }
        } catch (Exception ignored) {
        }
        float tempMaxpeed;
        try {

            tempMaxpeed = Float.parseFloat(tvMaxSpeed.getText().toString());


        } catch (java.lang.NumberFormatException nfe) {

            tempMaxpeed = 0.0f;

        }

        prefs.edit().putFloat("maxSpeed", tempMaxpeed);
    }

    private void displayNotification() {

        mbuilder.setSmallIcon(R.mipmap.ic_launcher);
        mbuilder.setContentTitle("SpeedoMeter is running...");
        mbuilder.setContentText("Click to view");

        Intent resultIntent = new Intent(context, MenuActivity.class);
        resultIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);

        TaskStackBuilder stackBuilder = TaskStackBuilder.create(context);
        stackBuilder.addParentStack(MenuActivity.class);

        stackBuilder.addNextIntent(resultIntent);

        PendingIntent resultPendingIntent = stackBuilder.getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT);
        mbuilder.setContentIntent(resultPendingIntent);

        if (mnotice != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                mnotice.createNotificationChannel(new NotificationChannel("ChannelID115",
                        "ChannelTitle",
                        NotificationManager.IMPORTANCE_DEFAULT));
            }
            mnotice.notify(1337, mbuilder.build());
        }
    }

    private void removeNotification() {
        if (mnotice != null) {
            mnotice.cancel(1337);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        context.getMenuInflater().inflate(R.menu.main, menu);
        return super.onCreateOptionsMenu(menu);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        switch (item.getItemId()) {
            case R.id.action_settings:
                Intent intent = new Intent();
                intent.setClass(context, SettingsActivity.class);
                startActivity(intent);
                return true;
            case R.id.action_quit:
                context.finish();
                System.exit(0);
                return true;

        }
        return super.onOptionsItemSelected(item);
    }

    private boolean isLocationEnabled(Context mContext) {


        LocationManager locationManager = (LocationManager)
                mContext.getSystemService(Context.LOCATION_SERVICE);
        assert locationManager != null;
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
    }

    @Override
    protected void onDestroy() {
        if (mAdView != null) {
            mAdView.destroy();
        }
        durationTV.stop();
        super.onDestroy();
    }

    @SuppressLint("StaticFieldLeak")
    private class SpeedTask extends AsyncTask<String, Void, String> {
        float speed = 0.0f;
        double lat;
        LocationManager locationManager;

        @Override
        protected String doInBackground(String... params) {
            locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);


            return null;

        }

        protected void onPostExecute(String result) {
            tvUnit.setText(unit[unitType - 1]);
            LocationListener listener = new LocationListener() {
                float filtSpeed;
                float localspeed;

                @SuppressLint("SetTextI18n")
                @Override
                public void onLocationChanged(Location location) {
                    speed = location.getSpeed();
                    float multiplier = 3.6f;

                    switch (unitType) {
                        case 1:
                            multiplier = 3.6f;
                            break;
                        case 2:
                            multiplier = 2.25f;
                            break;
                        case 3:
                            multiplier = 1.0f;
                            break;

                        case 4:
                            multiplier = 1.943856f;
                            break;

                    }

                    if (maxSpeed < speed) {
                        maxSpeed = speed;
                    }


                    localspeed = speed * multiplier;

                    filtSpeed = filter(filtSpeed, localspeed);


                    NumberFormat numberFormat = NumberFormat.getNumberInstance();
                    numberFormat.setMaximumFractionDigits(0);


                    lat = location.getLatitude();
                    //speedometer=(float) location.getLatitude();
                    Log.d("net.mypapit.speedview", "Speed " + localspeed + "latitude: " + lat + " longitude: " + location.getLongitude());
                    tvSpeed.setText(numberFormat.format(filtSpeed));

                    tvMaxSpeed.setText(numberFormat.format(maxSpeed * multiplier));

                    if (location.hasAltitude()) {
                        tvAccuracy.setText(numberFormat.format(location.getAccuracy()) + " m");
                    } else {
                        tvAccuracy.setText("NIL");
                    }

                    numberFormat.setMaximumFractionDigits(0);


                    if (location.hasBearing()) {

                        double bearing = location.getBearing();
                        String strBearing = "NIL";
                        if (bearing < 20.0) {
                            strBearing = "North";
                        } else if (bearing < 65.0) {
                            strBearing = "North-East";
                        } else if (bearing < 110.0) {
                            strBearing = "East";
                        } else if (bearing < 155.0) {
                            strBearing = "South-East";
                        } else if (bearing < 200.0) {
                            strBearing = "South";
                        } else if (bearing < 250.0) {
                            strBearing = "South-West";
                        } else if (bearing < 290.0) {
                            strBearing = "West";
                        } else if (bearing < 345.0) {
                            strBearing = "North-West";
                        } else if (bearing < 361.0) {
                            strBearing = "North";
                        }

                        tvHeading.setText(strBearing);
                    } else {
                        tvHeading.setText("NIL");
                    }

                    NumberFormat nf = NumberFormat.getInstance();

                    nf.setMaximumFractionDigits(4);


                    tvLat.setText(nf.format(location.getLatitude()));
                    tvLon.setText(nf.format(location.getLongitude()));


                }

                @Override
                public void onStatusChanged(String provider, int status, Bundle extras) {
                    // TODO Auto-generated method stub

                }

                @SuppressLint("SetTextI18n")
                @Override
                public void onProviderEnabled(String provider) {
                    tvSpeed.setText("STDBY");
                    tvMaxSpeed.setText("NIL");

                    tvLat.setText("LATITUDE");
                    tvLon.setText("LONGITUDE");
                    tvHeading.setText("HEADING");
                    tvAccuracy.setText("ACCURACY");

                }

                @SuppressLint("SetTextI18n")
                @Override
                public void onProviderDisabled(String provider) {
                    tvSpeed.setText("NOFIX");
                    tvMaxSpeed.setText("NOGPS");
                    tvLat.setText("LATITUDE");
                    tvLon.setText("LONGITUDE");
                    tvHeading.setText("HEADING");
                    tvAccuracy.setText("ACCURACY");


                }

            };


            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                        && context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    return;
                }
            }
            {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.

            }
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, listener);


        }


        private float filter(final float prev, final float curr) {

            if (Float.isNaN(prev)) {
                return curr;
            }

            if (Float.isNaN(curr)) {
                return prev;
            }

            return (float) (curr / 2 + prev * (1.0 - 1.0 / 2));
        }


    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }


}



