package com.megafreeapps.speedometer.live.camera.speed.detector.freegps.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class Utils
{

    public static final long FASTEST_LOCATION_INTERVAL = 5000;
    public static final int UPDATE_INTERVAL = 2 * 1000;
    public static final long LOCATION_INTERVAL = 10000;
    public static final int FASTEST_INTERVAL = 1000;
    public static String RELEASE_TOPIC_FOR_ACCOUNT = "topic_megaappslivespeedometer";
    public static String DEBUG_TOPIC_FOR_ACCOUNT = "test_topic_megaappslivespeedometer";

    public static String GetCustomDate(String s)
    {
        return new SimpleDateFormat(s, Locale.ENGLISH).format(Calendar.getInstance().getTime());
    }
}