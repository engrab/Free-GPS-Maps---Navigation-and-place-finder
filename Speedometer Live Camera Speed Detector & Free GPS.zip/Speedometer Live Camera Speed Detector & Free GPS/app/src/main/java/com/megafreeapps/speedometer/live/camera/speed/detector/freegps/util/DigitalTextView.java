package com.megafreeapps.speedometer.live.camera.speed.detector.freegps.util;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Typeface;
import android.util.AttributeSet;

public class DigitalTextView extends android.support.v7.widget.AppCompatTextView {
    public DigitalTextView(Context context) {
        super(context);
        setTypeFace(context);
    }

    public DigitalTextView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setTypeFace(context);
    }

    public DigitalTextView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        setTypeFace(context);
    }

    private void setTypeFace(Context context) {
        setTypeface(Typeface.createFromAsset(context.getAssets(), "digital_seven_font.ttf"));
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
    }
}
