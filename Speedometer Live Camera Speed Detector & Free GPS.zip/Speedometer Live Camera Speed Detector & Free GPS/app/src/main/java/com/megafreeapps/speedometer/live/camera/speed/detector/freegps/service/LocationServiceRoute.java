package com.megafreeapps.speedometer.live.camera.speed.detector.freegps.service;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.NotificationCompat;

import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.AppController;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.R;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.activities.LiveSpeedoMeterActivity;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;

import java.text.DecimalFormat;
import java.util.List;

public class LocationServiceRoute extends Service
{
    public static final String CHANNEL_ID = "location_channel";
    private static final int NOTIFICATION_ID = 130;
    double speed = 0;
    MediaPlayer mediaPlayer;
    NotificationManager notificationManager;
    FusedLocationProviderClient mFusedLocationClient;

    LocationCallback mLocationCallback = new LocationCallback()
    {
        @Override
        public void onLocationResult(LocationResult locationResult)
        {
            if (locationResult != null)
            {
                List<Location> locationList = locationResult.getLocations();
                if (locationList != null && locationList.size() > 0)
                {
                    //The last location in the list is the newest
                    Location location = locationList.get(locationList.size() - 1);
                    if (LiveSpeedoMeterActivity.Speedometer != null && LiveSpeedoMeterActivity.Speedometer.getContext() != null)
                    {
                        LiveSpeedoMeterActivity.Speedometer.setText(String.valueOf(new DecimalFormat("#.##").format(speed) + " \nkm/hr"));
                    }
                    if (speed > LiveSpeedoMeterActivity.maxSpeed)
                    {
                        notificationManager.notify(NOTIFICATION_ID, buildNotification("Running on high speedometer. Save your speedometer.", "Alert " + String.valueOf(new DecimalFormat("#.##")
                                .format(speed) + " km/hr")));
                        if (mediaPlayer == null)
                        {
                            mediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.speech);
                            mediaPlayer.setLooping(true);
                            mediaPlayer.start();
                        }
                    }
                    else
                    {
                        notificationManager.notify(NOTIFICATION_ID, buildNotification("Your speedometer is " + String.valueOf(new DecimalFormat("#.##")
                                .format(speed) + " km/hr"), getString(R.string.app_name)));
                        stopMediaPlayer();
                    }
                    speed = location.getSpeed() * 18 / 5;
                }
            }
        }
    };

    @Nullable
    @Override
    public IBinder onBind(Intent intent)
    {
        startLocationUpdates();
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId)
    {
//        if (intent != null && STOP_SERVICE.equals(intent.getAction()))
//        {
//            stopLocationUpdates();
//            stopMediaPlayer();
//            removeNotification();
//            stopSelf();
//        }
//        else
//        {
        startLocationUpdates();
        startForeground(NOTIFICATION_ID, buildNotification("Speed detection activated.", getString(R.string.app_name)));
//        }
//        return super.onStartCommand(intent, flags, startId);
        return START_STICKY;
    }

    protected void stopLocationUpdates()
    {
        if (mLocationCallback != null && mFusedLocationClient != null)
        {
            mFusedLocationClient.removeLocationUpdates(mLocationCallback);
        }
    }

    protected void startLocationUpdates()
    {
        try
        {
            mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
            if (mLocationCallback != null && AppController.getAppInstance().getGlobalLocationRequest() != null)
            {
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return;
                }
                mFusedLocationClient.requestLocationUpdates(
                        AppController.getAppInstance().getGlobalLocationRequest(), mLocationCallback, null);
            }
        }
        catch (Exception ignored)
        {
        }
    }

    private Notification buildNotification(String text, String title)
    {
        Intent intent = new Intent(getApplicationContext(), LiveSpeedoMeterActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(), 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        Bitmap artwork = BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher);
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setAutoCancel(false)
                .setSound(null)
                // Set the Notification color
                .setColor(getResources().getColor(R.color.colorAccent))
                // Set the large and small icons
                .setLargeIcon(artwork)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentIntent(pendingIntent)
                // Set Notification content information
                .setContentText(text)
                .setContentTitle(title);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        {
            notificationBuilder.setColorized(true);
        }
        /*notificationBuilder.setPriority(NotificationCompat.PRIORITY_HIGH);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
        {
            notificationBuilder.setCategory(Notification.CATEGORY_MESSAGE);
        }*/

        //create notification
//        notificationManager.notify(NOTIFICATION_ID, notificationBuilder.build());
        return notificationBuilder.build();
    }

    @Override
    public void onCreate()
    {
        super.onCreate();
        notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        createNotificationChannel();
//        notificationManager.notify(NOTIFICATION_ID, buildNotification("Speed detection activated.", getString(R.string.app_name)));
    }

    private void createNotificationChannel()
    {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && notificationManager != null)
        {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, getResources().getString(R.string.app_name),
                    NotificationManager.IMPORTANCE_DEFAULT);
            channel.setSound(null, null);
            notificationManager.createNotificationChannel(channel);
        }
    }

    @Override
    public boolean onUnbind(Intent intent)
    {
        stopLocationUpdates();
        stopMediaPlayer();
        removeNotification();
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy()
    {
        stopLocationUpdates();
        stopMediaPlayer();
        removeNotification();
        super.onDestroy();
    }

    private void stopMediaPlayer()
    {
        if (mediaPlayer != null)
        {
            if (mediaPlayer.isPlaying())
            {
                mediaPlayer.stop();
            }
            mediaPlayer.reset();
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

    private void removeNotification()
    {
        try
        {
            stopForeground(true);
        }
        catch (Exception e)
        {
        }
//        if (notificationManager != null)
//        {
//            notificationManager.cancel(NOTIFICATION_ID);
//        }
    }

    public class LocalBinder extends Binder
    {

        public LocationServiceRoute getService()
        {
            return LocationServiceRoute.this;
        }


    }


}

