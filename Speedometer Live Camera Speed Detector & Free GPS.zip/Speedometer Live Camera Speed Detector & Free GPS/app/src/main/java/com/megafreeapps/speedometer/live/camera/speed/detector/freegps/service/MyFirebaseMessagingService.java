package com.megafreeapps.speedometer.live.camera.speed.detector.freegps.service;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.view.View;
import android.widget.RemoteViews;

import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.BuildConfig;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.R;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.util.Utils;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.squareup.picasso.Picasso;

import java.util.Map;

import static android.support.constraint.Constraints.TAG;

public class MyFirebaseMessagingService extends FirebaseMessagingService
{
    private static int count = 0;
    private Map<String, String> data;

    @Override
    public void onNewToken(String s)
    {
        super.onNewToken(s);
        Log.d(TAG, "Refreshed token: " + s);
        try
        {
            if (FirebaseInstanceId.getInstance() != null && FirebaseInstanceId.getInstance().getId() != null &&
                    !FirebaseInstanceId.getInstance().getId().isEmpty())
            {
                if (BuildConfig.DEBUG)
                {
                    FirebaseMessaging.getInstance().subscribeToTopic(Utils.DEBUG_TOPIC_FOR_ACCOUNT);
                }
                else
                {
                    FirebaseMessaging.getInstance().subscribeToTopic(Utils.RELEASE_TOPIC_FOR_ACCOUNT);
                    FirebaseMessaging.getInstance().unsubscribeFromTopic(Utils.DEBUG_TOPIC_FOR_ACCOUNT);
                }
            }
        }
        catch (Exception e)
        {
            Log.e("FirebaseMessaging", e.toString());
        }
    }

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage)
    {
        data = remoteMessage.getData();
        if (data != null && !data.isEmpty())
        {
            String standard = "https://play.google.com/store/apps/details?id=";
            try
            {
                String id = data.get("app_url").substring(standard.length());
                if (BuildConfig.DEBUG)
                {
                    Log.e("package sent ", id);
                }

                if (!isAppInstalled(id, this))
                {
                    new Handler(Looper.getMainLooper()).post(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            sendCustomNotification();
                        }
                    });
                }

            }
            catch (Exception e)
            {
                if (BuildConfig.DEBUG)
                {
                    Log.e("FcmFireBase", "package not valid");
                }
            }
        }
    }

    //This method is only generating push notification
    private void sendCustomNotification()
    {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(data.get("app_url")));
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0 /* request code */, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        RemoteViews remoteViews = new RemoteViews(getPackageName(), R.layout.custom_notification);

        String longDesc = data.get("long_desc_");
        remoteViews.setTextViewText(R.id.tv_title, data.get("title"));
        remoteViews.setTextViewText(R.id.tv_short_desc, data.get("short_desc"));
        remoteViews.setTextViewText(R.id.tv_long_desc, longDesc);
        remoteViews.setViewVisibility(R.id.tv_long_desc, (longDesc != null && !longDesc.isEmpty()) ? View.VISIBLE : View.GONE);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, data.get("title"))
                .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
                .setAutoCancel(true)
                .setSmallIcon(R.drawable.ic_ad_small)
                .setContentIntent(pendingIntent)
                .setOnlyAlertOnce(true)
                .setCustomContentView(remoteViews)
                .setCustomBigContentView(remoteViews);

        NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        if (mNotificationManager != null)
        {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            {
                mNotificationManager.createNotificationChannel(new NotificationChannel(data.get("title"),
                        "Channel human readable title",
                        NotificationManager.IMPORTANCE_DEFAULT));
            }
            count++;
            mNotificationManager.notify(count, builder.build());
        }

        Picasso.get()
                .load(data.get("icon"))
                .into(remoteViews, R.id.iv_icon, count, builder.build());
        Picasso.get()
                .load(data.get("feature"))
                .into(remoteViews, R.id.iv_feature, count, builder.build());
    }

    private boolean isAppInstalled(String uri, Context context)
    {
        PackageManager pm = context.getPackageManager();
        try
        {
            //            packageInfo
            return pm.getApplicationInfo(uri, 0).enabled;
        }
        catch (PackageManager.NameNotFoundException e)
        {
            return false;
        }
    }
}
