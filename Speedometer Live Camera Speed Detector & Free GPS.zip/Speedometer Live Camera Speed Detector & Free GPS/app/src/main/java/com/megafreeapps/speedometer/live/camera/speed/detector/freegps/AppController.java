package com.megafreeapps.speedometer.live.camera.speed.detector.freegps;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.location.Location;
import android.support.annotation.NonNull;

import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.util.FastSave;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.util.Utils;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;

public class AppController extends Application implements GoogleApiClient.OnConnectionFailedListener
{

    private static AppController appController;
    private GoogleApiClient mGoogleApiClient;
    private LocationRequest mLocationRequest;
    private Location globalLocation;

    public AppController()
    {
        appController = this;
    }

    public static AppController getAppInstance()
    {
        return appController;
    }

    @Override
    public void onCreate()
    {
        super.onCreate();
        try
        {

            SharedPreferences preferences = getSharedPreferences("AddressPref", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = preferences.edit();
            editor.clear();
            editor.apply();
        }
        catch (Exception ignored)
        {
        }
        FastSave.init(this);
        initialize();
    }

    public void initialize()
    {
        mLocationRequest = LocationRequest.create()
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                .setInterval(Utils.UPDATE_INTERVAL)
                .setFastestInterval(Utils.FASTEST_INTERVAL);

        if (mGoogleApiClient == null)
        {
            mGoogleApiClient = new GoogleApiClient.Builder(this)
                    .addOnConnectionFailedListener(this)
                    .addApi(LocationServices.API)
                    .build();
            mGoogleApiClient.connect();
        }
    }

    public LocationRequest getGlobalLocationRequest()
    {
        return mLocationRequest;
    }

    public GoogleApiClient getGlobalGoogleApiClient()
    {
        return mGoogleApiClient;
    }

    public Location getGlobalLocation()
    {
        return globalLocation;
    }

    public void setGlobalLocation(Location location)
    {
        globalLocation = location;
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult)
    {
        if (!mGoogleApiClient.isConnected() && !mGoogleApiClient.isConnecting())
        {
            mGoogleApiClient.connect();
        }
    }
}
