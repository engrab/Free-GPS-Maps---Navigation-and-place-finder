package com.megafreeapps.speedometer.live.camera.speed.detector.freegps.compass.fragments;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.widget.Toast;


import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.R;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.compass.sensor.SensorListener;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.compass.sensor.view.AccelerometerView;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.compass.sensor.view.CompassView2;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.compass.utils.Utility;

import java.util.Objects;

import static com.megafreeapps.speedometer.live.camera.speed.detector.freegps.compass.utils.Utility.getDirectionText;

/**
 * Created by Engr on 12/23/2018.
 */

public class CompassFragment extends BaseFragment implements SensorListener.OnValueChangedListener {
    public static final String TAG = "CompassFragment";
    private static final int REQUEST_ENABLE_GPS = 1002;
    private CompassView2 mCompassView;
    private AccelerometerView mAccelerometerView;
    private SensorListener mSensorListener;

    public static CompassFragment newInstance() {

        Bundle args = new Bundle();

        CompassFragment fragment = new CompassFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        bindView();


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            mSensorListener = new SensorListener(Objects.requireNonNull(getContext()));
        }
        mSensorListener.setOnValueChangedListener(this);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            if (!Utility.isNetworkAvailable(Objects.requireNonNull(getContext()))) {
                Toast.makeText(getContext(), "No internet access", Toast.LENGTH_SHORT).show();
            } else {
                LocationManager manager = (LocationManager) getContext()
                        .getSystemService(Context.LOCATION_SERVICE);
                if (manager != null && !manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                    buildAlertMessageNoGps();
                }
            }
        }

//        onUpdateLocationData(null);
    }

    private void bindView() {
        mCompassView = (CompassView2) findViewById(R.id.compass_view);
        mAccelerometerView = (AccelerometerView) findViewById(R.id.accelerometer_view);

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    public void onStart() {
        super.onStart();
        if (mSensorListener != null) {
            mSensorListener.start();
        }
    }

    @Override
    public void onStop() {
        if (mSensorListener != null) {
            mSensorListener.stop();
        }
        super.onStop();

    }


    @Override
    public void onRotationChanged(float azimuth, float roll, float pitch) {
        String str = ((int) azimuth) + "° " + getDirectionText(azimuth);
        mCompassView.getSensorValue().setRotation(azimuth, roll, pitch);
        mAccelerometerView.getSensorValue().setRotation(azimuth, roll, pitch);

    }

    @Override
    public void onMagneticFieldChanged(float value) {
        mCompassView.getSensorValue().setMagneticField(value);
    }

    @Override
    public int getLayout() {
        return R.layout.fragment_compass;
    }

    //https://stackoverflow.com/questions/39336461/how-can-i-enable-or-disable-the-gps-programmatically-on-android-6-x
    private void buildAlertMessageNoGps() {
        AlertDialog.Builder builder = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.KITKAT) {
            builder = new AlertDialog.Builder(Objects.requireNonNull(getContext()));
        }
        if (builder != null) {
            builder.setMessage("Your GPS seems to be disabled, do you want to enable it?")
                    .setCancelable(false)
                    .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                            startActivityForResult(intent, REQUEST_ENABLE_GPS);
                        }
                    })
                    .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                        public void onClick(final DialogInterface dialog, int id) {
                            dialog.cancel();
                        }
                    });
        }
        AlertDialog alert = null;
        if (builder != null) {
            alert = builder.create();
        }
        if (alert != null) {
            alert.show();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case REQUEST_ENABLE_GPS:
                break;
        }
    }
}
