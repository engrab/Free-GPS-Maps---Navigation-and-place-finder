package com.megafreeapps.speedometer.live.camera.speed.detector.freegps.compass.utils;

import android.util.Log;

/**
 * Created by Duy on 10/16/2017.
 */
public class DLog {
    public static void d(String tag, String s) {
        Log.d(tag, s);
    }
}
