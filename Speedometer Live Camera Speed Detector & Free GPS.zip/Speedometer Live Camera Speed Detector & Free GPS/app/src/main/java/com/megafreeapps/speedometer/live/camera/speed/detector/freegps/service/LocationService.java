package com.megafreeapps.speedometer.live.camera.speed.detector.freegps.service;

import android.Manifest;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.permissions.Permission;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.util.Utils;

import java.util.List;

public class LocationService extends Service
{

    public static final String ACTION_LOCATION_BROADCAST = LocationService.class.getName() + "LocationBroadcast";
    public static final String LATITUDE = "latitude";
    public static final String LONGITUDE = "longitude";
    public static final String SPEED = "speedometer";
    private static final String TAG = LocationListener.class.getSimpleName();
    FusedLocationProviderClient mFusedLocationClient;
    LocationCallback mLocationCallback = new LocationCallback()
    {
        @Override
        public void onLocationResult(LocationResult locationResult)
        {
            if (locationResult == null)
            {
                return;
            }
            List<Location> locationList = locationResult.getLocations();
            if (locationList != null && locationList.size() > 0)
            {
                //The last location in the list is the newest
                Location location = locationList.get(locationList.size() - 1);
                if (location != null)
                {
                    Log.d(TAG, "== location != null");

                    //Send result to activities
                    sendMessageToUI(String.valueOf(location.getSpeed() * 18 / 5), String.valueOf(location.getLatitude()), String.valueOf(location.getLongitude()));
                }
            }
        }
    };
    private LocationRequest mLocationRequest = LocationRequest.create();

    @Override
    public int onStartCommand(Intent intent, int flags, int startId)
    {
        init();

        return START_STICKY;
    }

    private void init()
    {
        try
        {
            mLocationRequest.setInterval(Utils.LOCATION_INTERVAL);
            mLocationRequest.setFastestInterval(Utils.FASTEST_LOCATION_INTERVAL);
            mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
            mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
            if (mLocationCallback != null)
            {
                String[] multiplePermissions = {Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION};
                int multiplePermissionsCode = 101;
                if (!new Permission(this, multiplePermissions, multiplePermissionsCode).checkPermissions())
                {
                    Log.d(TAG, "== Error On onConnected() Permission not granted");
                    return;
                }
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return;
                }
                mFusedLocationClient.requestLocationUpdates(mLocationRequest, mLocationCallback, null);
            }
        }
        catch (SecurityException ignored)
        {
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent)
    {
        return null;
    }

    @Override
    public boolean onUnbind(Intent intent)
    {
        stopLocationUpdates();
        return super.onUnbind(intent);
    }

    protected void stopLocationUpdates()
    {
        if (mLocationCallback != null && mFusedLocationClient != null)
        {
            mFusedLocationClient.removeLocationUpdates(mLocationCallback);
        }
    }

    private void sendMessageToUI(String speed, String latitude, String longitude)
    {
        Log.d(TAG, "Sending info...");

        Intent intent = new Intent(ACTION_LOCATION_BROADCAST);
        intent.putExtra(SPEED, speed);
        intent.putExtra(LATITUDE, latitude);
        intent.putExtra(LONGITUDE, longitude);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }
}
