package com.megafreeapps.speedometer.live.camera.speed.detector.freegps.activities;

import android.Manifest;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlacePicker;
import com.google.android.gms.maps.model.LatLng;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.AppController;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.R;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.compass.CompassActivity;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.util.FastSave;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.util.PurchasePref;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.util.Utils;

import java.util.List;

public class MenuActivity extends AppCompatActivity implements View.OnClickListener {

    AdView mAdView;
    InterstitialAd mInterstitialAd;
    int viewId = 0;
    Activity context;
    FusedLocationProviderClient mFusedLocationClient;
    Location location;

    TextView routeFinder, compass, liveSpeedometer, nearbyPlaces, voiceNavigation, favouritePlaces;
    int PLACE_PICKER_REQUEST = 11;
    LocationCallback mLocationCallback = new LocationCallback() {
        @Override
        public void onLocationResult(LocationResult locationResult) {
            if (locationResult != null) {
                List<Location> locationList = locationResult.getLocations();
                if (locationList.size() > 0) {
                    //The last location in the list is the newest
                    location = locationList.get(locationList.size() - 1);
                    AppController.getAppInstance().setGlobalLocation(location);
                    if (location != null) {
                        FastSave.getInstance().saveObject("latLng", new LatLng(location.getLatitude(), location.getLongitude()));
                    }
                }
            }
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_menu);
        context = MenuActivity.this;

        PurchasePref purchasePref = new PurchasePref(getApplicationContext());
        if (purchasePref.getItemDetail().equals("") && purchasePref.getProductId().equals("")) {
            mAdView = this.findViewById(R.id.adView);
            mAdView.loadAd(new AdRequest.Builder().build());
            mAdView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                    super.onAdLoaded();
                    mAdView.setVisibility(View.VISIBLE);
                }
            });
            mInterstitialAd = new InterstitialAd(this);
            mInterstitialAd.setAdUnitId(getString(R.string.interstitial_ad_id));
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
            mInterstitialAd.setAdListener(new AdListener() {
                @Override
                public void onAdClosed() {
                    super.onAdClosed();

                    mInterstitialAd.loadAd(new AdRequest.Builder().build());
                    clickListeners();

                }
            });
        }
        Typeface font = Typeface.createFromAsset(context.getAssets(), "franklingothic.ttf");

        routeFinder = findViewById(R.id.tv_route_finder);
        routeFinder.setTypeface(font);
        routeFinder.setOnClickListener(this);
        findViewById(R.id.tv_route_finder_layout).setOnClickListener(this);
        findViewById(R.id.iv_route_finder).setOnClickListener(this);

        compass = findViewById(R.id.tv_compass);
        compass.setTypeface(font);
        compass.setOnClickListener(this);
        findViewById(R.id.tv_compass_layout).setOnClickListener(this);
        findViewById(R.id.iv_compass).setOnClickListener(this);

        liveSpeedometer = findViewById(R.id.tv_speed_camera);
        liveSpeedometer.setTypeface(font);
        liveSpeedometer.setOnClickListener(this);
        findViewById(R.id.tv_speed_camera_layout).setOnClickListener(this);
        findViewById(R.id.iv_live_speed).setOnClickListener(this);

        findViewById(R.id.iv_speedometer).setOnClickListener(this);

        voiceNavigation = findViewById(R.id.tv_voice_navigation);
        voiceNavigation.setTypeface(font);
        voiceNavigation.setOnClickListener(this);
        findViewById(R.id.tv_voice_navigation_layout).setOnClickListener(this);
        findViewById(R.id.iv_voice_navigation).setOnClickListener(this);

        nearbyPlaces = findViewById(R.id.tv_near_by_places);
        nearbyPlaces.setTypeface(font);
        nearbyPlaces.setOnClickListener(this);
        findViewById(R.id.tv_near_by_places_layout).setOnClickListener(this);
        findViewById(R.id.iv_near_by_places).setOnClickListener(this);


        favouritePlaces = findViewById(R.id.tv_favourite_place);
        favouritePlaces.setTypeface(font);
        favouritePlaces.setOnClickListener(this);
        findViewById(R.id.iv_favourite_places).setOnClickListener(this);
        findViewById(R.id.tv_route_finder_layout).setOnClickListener(this);

        startLocationUpdates();

    }

    private void clickListeners() {
        switch (viewId) {

            case R.id.tv_route_finder:
            case R.id.tv_route_finder_layout:
            case R.id.iv_route_finder:

                startActivity(new Intent(MenuActivity.this, RouteFinderActivity.class));
                break;
            case R.id.tv_voice_navigation:
            case R.id.tv_voice_navigation_layout:
            case R.id.iv_voice_navigation:

                startActivity(new Intent(MenuActivity.this, VoiceNavigationActivity.class));
                break;
            case R.id.tv_compass:
            case R.id.tv_compass_layout:
            case R.id.iv_compass:

                startActivity(new Intent(MenuActivity.this, CompassActivity.class));
                break;

            case R.id.tv_speed_camera:
            case R.id.tv_speed_camera_layout:
            case R.id.iv_live_speed:
                startActivity(new Intent(MenuActivity.this, LiveSpeedoMeterActivity.class));
                break;

            case R.id.tv_near_by_places:
            case R.id.tv_near_by_places_layout:
            case R.id.iv_near_by_places:
                startActivity(new Intent(MenuActivity.this, NearByPlacesActivity.class));
                break;
            case R.id.tv_favourite_places_layout:
            case R.id.tv_favourite_place:
            case R.id.iv_favourite_places:
                startActivity(new Intent(MenuActivity.this, FavouritePlacesActivity.class));
                break;
            case R.id.iv_speedometer:
                startActivity(new Intent(MenuActivity.this, DigitalSpeedoMeterActivity.class));
                break;
        }
    }

    public void onClick(View view) {
        viewId = view.getId();
        if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
            mInterstitialAd.show();
        } else {
            clickListeners();
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        if (mAdView != null) {
            mAdView.resume();
        }

    }

    @Override
    protected void onPause() {

        if (mAdView != null) {
            mAdView.pause();
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (mAdView != null) {
            mAdView.destroy();
        }

        stopLocationUpdates();
        super.onDestroy();
    }

    public void onBackPressed() {
        super.onBackPressed();

    }


    protected void stopLocationUpdates() {
        if (mLocationCallback != null && mFusedLocationClient != null) {
            mFusedLocationClient.removeLocationUpdates(mLocationCallback);
        }

    }

    protected void startLocationUpdates() {
        try {
            LocationRequest mLocationRequest = LocationRequest.create()
                    .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                    .setInterval(Utils.UPDATE_INTERVAL)
                    .setFastestInterval(Utils.FASTEST_INTERVAL);
            mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
            if (mLocationCallback != null && mFusedLocationClient != null && mLocationRequest != null) {
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return;
                }
                mFusedLocationClient.requestLocationUpdates(
                        mLocationRequest, mLocationCallback, null);
            }
        } catch (SecurityException ignored) {
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PLACE_PICKER_REQUEST) {
            if (resultCode == RESULT_OK && data != null) {
                try {
                    Place place = PlacePicker.getPlace(context, data);
                    Uri gmmIntentUri = Uri.parse("google.navigation:q=" + place.getName());
                    Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                    mapIntent.setPackage("com.google.android.apps.maps");
                    if (mapIntent.resolveActivity(context.getPackageManager()) != null) {
                        startActivity(mapIntent);
                    }
                } catch (Exception ignored) {
                }
            }
        }
    }


}