package com.megafreeapps.speedometer.live.camera.speed.detector.freegps.activities;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.widget.Autocomplete;
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.R;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.adapters.VoiceNavigationAdapter;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.util.PurchasePref;

import java.util.Arrays;
import java.util.List;

public class VoiceNavigationActivity extends AppCompatActivity implements View.OnClickListener {
    int PLACE_PICKER_REQUEST = 11;
    int VOICE_REQUEST = 12;
    Activity context;
    AdView mAdView;
    RecyclerView recyclerView;
    InterstitialAd mInterstitialAd;
    TextView voiceNavigation;
    int viewId = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_voice_navigation);



            PurchasePref purchasePref = new PurchasePref(getApplicationContext());
            if (purchasePref.getItemDetail().equals("") && purchasePref.getProductId().equals("")) {
                mAdView = this.findViewById(R.id.adView);
                mAdView.loadAd(new AdRequest.Builder().build());
                mAdView.setAdListener(new AdListener() {
                    @Override
                    public void onAdLoaded() {
                        super.onAdLoaded();
                        mAdView.setVisibility(View.VISIBLE);
                    }
                });
                mInterstitialAd = new InterstitialAd(this);
                mInterstitialAd.setAdUnitId(getString(R.string.interstitial_ad_id));
                mInterstitialAd.loadAd(new AdRequest.Builder().build());
                mInterstitialAd.setAdListener(new AdListener() {
                    @Override
                    public void onAdClosed() {
                        super.onAdClosed();

                        mInterstitialAd.loadAd(new AdRequest.Builder().build());
                        clickListeners();

                    }
                });
            }


        Init();
    }


    private void Init() {
        context = VoiceNavigationActivity.this;
        recyclerView = findViewById(R.id.rvItems);
        recyclerView.setLayoutManager(new LinearLayoutManager(context));

        Typeface font = Typeface.createFromAsset(context.getAssets(), "franklingothic.ttf");
        voiceNavigation = findViewById(R.id.tv_voice_navigation);
        voiceNavigation.setTypeface(font);

        findViewById(R.id.tvVoice).setOnClickListener(this);
        findViewById(R.id.iv).setOnClickListener(this);
        findViewById(R.id.cv).setOnClickListener(this);
        findViewById(R.id.ivRecorder).setOnClickListener(this);
    }


    private void clickListeners() {
        switch (viewId) {
            case R.id.tvVoice:
            case R.id.iv:
            case R.id.cv:
                List<Place.Field> fields = Arrays.asList(com.google.android.libraries.places.api.model.Place.Field.ID, com.google.android.libraries.places.api.model.Place.Field.NAME, com.google.android.libraries.places.api.model.Place.Field.LAT_LNG);
                Intent intents = new Autocomplete.IntentBuilder(AutocompleteActivityMode.OVERLAY, fields).build(context);
                startActivityForResult(intents, PLACE_PICKER_REQUEST);

//                try {
//                    PlacePicker.IntentBuilder builder = new PlacePicker.IntentBuilder();
//                    startActivityForResult(builder.build(context), PLACE_PICKER_REQUEST);
//                } catch (GooglePlayServicesRepairableException e) {
//                    // TODO: Handle the error.
//                } catch (GooglePlayServicesNotAvailableException e) {
//                    // TODO: Handle the error.
//                }
                break;
            case R.id.ivRecorder:
                try {
                    speechRecognize();
                } catch (Exception ignored) {
                }
                break;

        }
    }

    @Override
    public void onClick(View view) {

        viewId = view.getId();
        if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
            mInterstitialAd.show();
        } else {
            clickListeners();
        }
    }



    private void speechRecognize() {
        try {
            if (context.getPackageManager().queryIntentActivities(new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH), 0).size() != 0) {
                Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_PROMPT, getString(R.string.txt_where_you_want_go));
                startActivityForResult(intent, VOICE_REQUEST);
            } else {
                AlertDialog alertDialog = new AlertDialog.Builder(context).create();
                alertDialog.setTitle(getString(R.string.txt_warning));
                alertDialog.setMessage(getString(R.string.txt_voice_recognition_not_active));
                alertDialog.setButton(Dialog.BUTTON_POSITIVE, getString(R.string.txt_ok), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                alertDialog.show();
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null) {
            if (requestCode == PLACE_PICKER_REQUEST) {
                try {
                    Place place = Autocomplete.getPlaceFromIntent(data);
                    Uri gmmIntentUri = Uri.parse("google.navigation:q=" + place.getName());
                    Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                    mapIntent.setPackage("com.google.android.apps.maps");
                    if (mapIntent.resolveActivity(context.getPackageManager()) != null) {
                        startActivity(mapIntent);
                    }
                } catch (Exception ignored) {
                }
            } else if (requestCode == VOICE_REQUEST) {

                try {
                    List<String> list = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    if (list != null && list.size() > 0) {
                        recyclerView.setAdapter(new VoiceNavigationAdapter(context, list));
                    } else {
                        recyclerView.setAdapter(null);
                    }
                } catch (Exception ignored) {
                }
            }
        }
    }

    @Override
    protected void onPause() {

        if (mAdView != null) {
            mAdView.pause();
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (mAdView != null) {
            mAdView.destroy();
        }

        super.onDestroy();
    }
    @Override
    protected void onResume() {
        super.onResume();
        if (mAdView != null) {
            mAdView.resume();
        }

    }

    public void onBackPressed() {
            super.onBackPressed();


    }
}
