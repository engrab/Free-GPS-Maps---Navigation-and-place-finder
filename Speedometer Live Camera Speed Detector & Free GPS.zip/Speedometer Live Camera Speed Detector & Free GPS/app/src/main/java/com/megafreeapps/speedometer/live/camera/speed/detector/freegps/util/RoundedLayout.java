package com.megafreeapps.speedometer.live.camera.speed.detector.freegps.util;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.Path.Direction;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.widget.RelativeLayout;

public class RoundedLayout extends RelativeLayout {
    /* renamed from: a */
    private float f9838a;
    /* renamed from: b */
    private float f9839b;
    /* renamed from: c */
    private float f9840c;
    /* renamed from: d */
    private float f9841d;
    /* renamed from: e */
    private int f9842e;
    /* renamed from: f */
    private int f9843f;
    /* renamed from: g */
    private int f9844g;
    /* renamed from: h */
    private float f9845h;
    /* renamed from: i */
    private float f9846i;
    /* renamed from: j */
    private boolean f9847j;
    /* renamed from: k */
    private Paint f9848k;
    /* renamed from: l */
    private Path f9849l;
    /* renamed from: m */
    private Path f9850m;
    /* renamed from: n */
    private Path f9851n;
    /* renamed from: o */
    private Path f9852o;
    /* renamed from: p */
    private boolean f9853p;
    /* renamed from: q */
    private RectF f9854q;
    /* renamed from: r */
    private RectF f9855r;
    /* renamed from: s */
    private int f9856s;

    public RoundedLayout(Context context) {
        this(context, null);
    }

    public RoundedLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public RoundedLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f9851n = new Path();
        this.f9849l = new Path();
        this.f9852o = new Path();
        this.f9850m = new Path();
        this.f9844g = 0;
        this.f9853p = false;
        this.f9842e = -3355444;
        this.f9846i = 1.0f;
        this.f9847j = false;
        this.f9848k = new Paint();
        this.f9854q = new RectF(0.0f, 0.0f, 0.0f, 0.0f);
        this.f9855r = new RectF(0.0f, 0.0f, 0.0f, 0.0f);
        this.f9846i = getResources().getDisplayMetrics().density;
        this.f9845h = m11007a(5.0f);
        this.f9848k.setAntiAlias(true);
        this.f9848k.setStyle(Style.STROKE);
        this.f9848k.setColor(this.f9842e);
        setBorderWidth(Math.round(m11007a(2.0f)));
    }

    /* renamed from: a */
    private float m11007a(float f) {
        return this.f9846i * f;
    }

    /* renamed from: a */
    private void m11008a() {
        if (!isInEditMode()) {
            this.f9850m.reset();
            this.f9850m.addCircle(this.f9838a, this.f9839b, Math.min(this.f9841d - ((float) this.f9843f), this.f9840c - ((float) this.f9843f)), Direction.CW);
            this.f9850m.close();
        }
    }

    /* renamed from: b */
    private void m11009b() {
        if (!isInEditMode()) {
            this.f9855r.left = getRect().left + ((float) this.f9843f);
            this.f9855r.top = getRect().top + ((float) this.f9843f);
            this.f9855r.right = getRect().right - ((float) this.f9843f);
            this.f9855r.bottom = getRect().bottom - ((float) this.f9843f);
            this.f9852o.reset();
            this.f9852o.addRoundRect(this.f9855r, this.f9845h - ((float) this.f9843f), this.f9845h - ((float) this.f9843f), Direction.CW);
            this.f9852o.close();
        }
    }

    protected void dispatchDraw(Canvas canvas) {
        this.f9856s = canvas.save();
        canvas.clipPath(this.f9847j ? this.f9849l : this.f9851n);
        super.dispatchDraw(canvas);
        canvas.restoreToCount(this.f9856s);
        if (this.f9853p) {
            canvas.drawPath(this.f9847j ? this.f9850m : this.f9852o, this.f9848k);
        }
    }

    public RectF getRect() {
        return this.f9854q;
    }

    protected void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        getRect().left = 0.0f;
        getRect().top = 0.0f;
        float f = (float) i;
        getRect().right = f;
        float f2 = (float) i2;
        getRect().bottom = f2;
        this.f9851n.reset();
        this.f9851n.addRoundRect(getRect(), this.f9845h, this.f9845h, Direction.CW);
        this.f9851n.close();
        this.f9841d = f / 2.0f;
        this.f9840c = f2 / 2.0f;
        this.f9838a = this.f9841d;
        this.f9839b = this.f9840c;
        this.f9849l.reset();
        this.f9849l.addCircle(this.f9838a, this.f9839b, Math.min(this.f9841d, this.f9840c), Direction.CW);
        this.f9849l.close();
        m11009b();
        m11008a();
    }

    public void setBorderColor(int i) {
        this.f9842e = i;
        this.f9848k.setColor(i);
        invalidate();
    }

    public void setBorderWidth(int i) {
        this.f9844g = i;
        this.f9843f = Math.round((float) (this.f9844g / 2));
        if (this.f9843f == 0) {
            this.f9843f = 1;
        }
        this.f9848k.setStrokeWidth((float) this.f9844g);
        m11008a();
        m11009b();
        invalidate();
    }

    public void setCornerRadius(int i) {
        this.f9845h = (float) i;
        invalidate();
    }

    public void setRect(RectF rectF) {
    }

    public void setShapeCircle(boolean z) {
        this.f9847j = z;
        invalidate();
    }
}
