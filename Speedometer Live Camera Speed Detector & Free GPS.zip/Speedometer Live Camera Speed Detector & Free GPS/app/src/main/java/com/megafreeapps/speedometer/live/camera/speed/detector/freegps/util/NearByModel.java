package com.megafreeapps.speedometer.live.camera.speed.detector.freegps.util;

public class NearByModel
{
    public String text;
    public int id;

    public NearByModel(int id, String text)
    {
        this.text = text;
        this.id = id;
    }
}
