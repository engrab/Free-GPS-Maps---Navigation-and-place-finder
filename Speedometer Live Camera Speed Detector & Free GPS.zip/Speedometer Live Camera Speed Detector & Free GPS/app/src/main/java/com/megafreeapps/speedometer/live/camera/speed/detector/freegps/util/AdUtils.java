package com.megafreeapps.speedometer.live.camera.speed.detector.freegps.util;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.View;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;


public class AdUtils
{


    public static void loadInterstitialAd(final InterstitialAd interstitialAd)
    {
        requestNewInterstitial(interstitialAd);
        interstitialAd.setAdListener(new AdListener()
        {
            @Override
            public void onAdClosed()
            {
                requestNewInterstitial(interstitialAd);
            }
        });
    }

    private static void requestNewInterstitial(InterstitialAd interstitialAd)
    {
        interstitialAd.loadAd(new AdRequest.Builder().build());
    }

    public static void showAdAndMoveForward(final Context context, final InterstitialAd interstitialAd, final Intent intent)
    {
        if (interstitialAd.isLoaded())
        { //agr gogole ne ad bj dya ha show ho jaega
            interstitialAd.show();
        }
        else
        {                         // aur agr ni bja to next page show ho jae

            context.startActivity(intent);
        }
        interstitialAd.setAdListener(new AdListener()
        {
            @Override
            public void onAdClosed()
            {       //ad close krne pr next page show kr dega
                requestNewInterstitial(interstitialAd);

                context.startActivity(intent);
            }
        });
    }

    public static void loadBannerAd(final AdView adView)
    {

        AdRequest adRequest = new AdRequest.Builder()
                .addTestDevice(AdRequest.DEVICE_ID_EMULATOR)
                .build();

        adView.setAdListener(new AdListener()
        {
            @Override
            public void onAdLoaded()
            {
                adView.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdClosed()
            {
            }

            @Override
            public void onAdFailedToLoad(int errorCode)
            {
            }

            @Override
            public void onAdLeftApplication()
            {

            }

            @Override
            public void onAdOpened()
            {
                super.onAdOpened();
            }
        });
        adView.loadAd(adRequest);
    }

    public static void backPressLoadAd(final Activity context, InterstitialAd interstitialAd)
    {
        if (interstitialAd != null && interstitialAd.isLoaded())
        {
            interstitialAd.show();
            interstitialAd.setAdListener(new AdListener()
            {
                @Override
                public void onAdClosed()
                {
                    context.finish();
                }
            });
        }
        else
        {
            context.finish();
        }
    }
}
