package com.megafreeapps.speedometer.live.camera.speed.detector.freegps.util;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Typeface;
import android.util.AttributeSet;

public class CustomTextView extends android.support.v7.widget.AppCompatTextView
{
    public CustomTextView(Context context)
    {
        super(context);
        setTypeFace(context);
    }

    private void setTypeFace(Context context)
    {
        setTypeface(Typeface.createFromAsset(context.getAssets(), "calibri.ttf"));
    }

    public CustomTextView(Context context, AttributeSet attrs)
    {
        super(context, attrs);
        setTypeFace(context);
    }

    public CustomTextView(Context context, AttributeSet attrs, int defStyle)
    {
        super(context, attrs, defStyle);
        setTypeFace(context);
    }

    protected void onDraw(Canvas canvas)
    {
        super.onDraw(canvas);
    }

}
