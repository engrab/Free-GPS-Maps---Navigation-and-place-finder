package com.megafreeapps.speedometer.live.camera.speed.detector.freegps;

import com.google.android.gms.maps.model.LatLng;

import java.io.Serializable;
import java.util.List;

public class LastLocationModel implements Serializable {
    private LatLng originLocation;
    private LatLng destinationLocation;
    private List<String> polyline;
    private String destinationAddress;
    private String temperature;
    private String description;
    private String icon;

    public LastLocationModel(LatLng originLocation, LatLng destinationLocation, List<String> polyline, String destinationAddress, String temperature, String description, String icon) {
        this.originLocation = originLocation;
        this.destinationLocation = destinationLocation;
        this.polyline = polyline;
        this.destinationAddress = destinationAddress;
        this.temperature = temperature;
        this.description = description;
        this.icon = icon;
    }

    public LatLng getOriginLocation() {
        return originLocation;
    }

    public LatLng getDestinationLocation() {
        return destinationLocation;
    }

    public List<String> getPolyline() {
        return polyline;
    }

    public String getDestinationAddress() {
        return destinationAddress;
    }

    public String getTemperature() {
        return temperature;
    }

    public String getDescription() {
        return description;
    }

    public String getIcon() {
        return icon;
    }
}
