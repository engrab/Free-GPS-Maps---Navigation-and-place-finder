package com.megafreeapps.speedometer.live.camera.speed.detector.freegps.modle;

public class MapItem {
    private String mMapName;
    private int mMapImage;

    public String getmMapName() {
        return mMapName;
    }

    public int getmMapImage() {
        return mMapImage;
    }

    public MapItem(String mapName, int mapImage){
        mMapName = mapName;
        mMapImage = mapImage;
    }
}
