package com.megafreeapps.speedometer.live.camera.speed.detector.freegps.compass;

import android.content.DialogInterface;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.R;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.compass.fragments.CompassFragment;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.compass.sensor.SensorUtil;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.compass.view.CustomViewPager;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.util.PurchasePref;

public class CompassActivity extends AppCompatActivity {
    AdView mAdView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_compass);

        PurchasePref purchasePref = new PurchasePref(getApplicationContext());
        if (purchasePref.getItemDetail().equals("") && purchasePref.getProductId().equals("")) {
            mAdView = this.findViewById(R.id.adView);
            mAdView.loadAd(new AdRequest.Builder().build());
            mAdView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                    super.onAdLoaded();
                    mAdView.setVisibility(View.VISIBLE);
                }
            });
        }
        if (hasSensor()) {
            createView();
        } else {
            showDialogUnsupported();
        }
    }

    private void createView() {
        CustomViewPager viewPager = findViewById(R.id.view_pager);
        FragmentPagerAdapter adapter = new FragmentPagerAdapter(getSupportFragmentManager()) {
            @Override
            public int getCount() {
                return 1;
            }

            @Override
            public Fragment getItem(int position) {
                switch (position) {
                    case 0:
                        return new CompassFragment();
                }
                return null;
            }
        };
        viewPager.setAdapter(adapter);
        viewPager.setCurrentItem(1);
    }

    private boolean hasSensor() {
        return SensorUtil.hasAccelerometer(this) && SensorUtil.hasMagnetometer(this);
    }

    private void showDialogUnsupported() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Your device unsupported Accelerometer sensor and Magnetometer");
        builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        }).create().show();
    }

    @Override
    protected void onPause()
    {
        super.onPause();
        if (mAdView != null)
        {
            mAdView.pause();
        }
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        if (mAdView != null)
        {
            mAdView.resume();
            mAdView.setVisibility(View.VISIBLE);
        }
    }

    @Override
    protected void onDestroy()
    {
        if (mAdView != null)
        {
            mAdView.destroy();
        }
        super.onDestroy();
    }
    @Override
    public void onBackPressed()
    {

           super.onBackPressed();

    }
}
