package com.megafreeapps.speedometer.live.camera.speed.detector.freegps.util;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.speech.RecognizerIntent;
import android.util.DisplayMetrics;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.location.places.ui.PlaceAutocomplete;
import com.google.android.gms.location.places.ui.PlacePicker;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.Dot;
import com.google.android.gms.maps.model.Gap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PatternItem;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.maps.android.PolyUtil;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.R;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class MapUtil
{

    public static void searchPlace(Activity context, int PLACE_SEARCH_REQUEST, String TAG)
    {
        try
        {
            context.startActivityForResult(new PlaceAutocomplete.IntentBuilder(PlaceAutocomplete.MODE_OVERLAY)
                    .build(context), PLACE_SEARCH_REQUEST);
        }
        catch (GooglePlayServicesRepairableException e)
        {
            Log.d(TAG, "Google Play Services Repairable Exception " + e.toString());

        }
        catch (GooglePlayServicesNotAvailableException e)
        {
            Log.d(TAG, "Google Play Services Not Available Exception " + e.toString());
        }
    }

    public static void promptSpeechInput(Activity context, int REQ_CODE_SPEECH_INPUT)
    {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT,
                context.getString(R.string.speech_prompt));
        try
        {
            context.startActivityForResult(intent, REQ_CODE_SPEECH_INPUT);
        }
        catch (ActivityNotFoundException a)
        {
            Toast.makeText(context,
                    context.getString(R.string.speech_not_supported),
                    Toast.LENGTH_SHORT).show();
        }
    }

    public static void pickPlace(Activity context, int PLACE_PICKER_REQUEST, String TAG)
    {
        PlacePicker.IntentBuilder builder = new PlacePicker.IntentBuilder();

        try
        {
            context.startActivityForResult(builder.build(context), PLACE_PICKER_REQUEST);
        }
        catch (GooglePlayServicesRepairableException e)
        {
            Log.d(TAG, e.toString());
        }
        catch (GooglePlayServicesNotAvailableException e)
        {
            Log.d(TAG, e.toString());
        }
    }

    public static void drawMap(Context context, GoogleMap map, String polyline, boolean isFirst, boolean isLast)
    {
        List<PatternItem> pattern = Arrays.asList(
                new Dot(), new Gap(2.5f));
        List<LatLng> latLngList = PolyUtil.decode(polyline);
        PolylineOptions options = new PolylineOptions();

        map.addPolyline(options.addAll(latLngList).geodesic(true).width(30.0f).color(context.getResources().getColor(R.color.map_polyline_color)));

        if (isFirst)
        {
            map.addMarker(new MarkerOptions().position(new LatLng(latLngList.get(0).latitude, latLngList.get(0).longitude)).icon(BitmapDescriptorFactory.fromResource(R.mipmap.ic_location_)));
        }
        else if (isLast)
        {
            map.addMarker(new MarkerOptions().position(new LatLng(latLngList.get(latLngList.size() - 1).latitude, latLngList.get(latLngList.size() - 1).longitude)).icon(BitmapDescriptorFactory.fromResource(R.mipmap.ic_location_)));
        }
    }

    public static void zoomMap(Activity context, final GoogleMap googleMap, List<LatLng> latLngList)
    {
        if (latLngList == null || latLngList.isEmpty())
        {
            return;
        }
        LatLngBounds.Builder builder = LatLngBounds.builder();

        for (int i = 0; i < latLngList.size(); i++)
        {
            builder.include(latLngList.get(i));
        }
        final LatLngBounds bounds = builder.build();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        context.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int height = displayMetrics.heightPixels;
        int width = displayMetrics.widthPixels;
        try
        {
            googleMap.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, width, height, 80), new GoogleMap.CancelableCallback()
            {
                @Override
                public void onFinish()
                {
                    googleMap.animateCamera(CameraUpdateFactory.newCameraPosition(new CameraPosition.Builder(googleMap.getCameraPosition())
                            .bearing(45)
                            .tilt(45)
                            .build()));
                }

                @Override
                public void onCancel()
                {

                }
            });
        }
        catch (Exception e)
        {
            Log.d("map", e.toString());
        }
    }

    public static Marker drawSinglePointMap(GoogleMap mMap, Marker marker, String placeName, LatLng latLng)
    {

        marker = mMap.addMarker(new MarkerOptions().position(latLng).title(placeName));
        CameraPosition cameraPosition = new CameraPosition.Builder()
                .target(latLng)      // Sets the center of the map to Mountain View
                .zoom(17)                   // Sets the zoom
                .bearing(90)                // Sets the orientation of the camera to east
                .tilt(90)                   // Sets the tilt of the camera to 30 degrees
                .build();                   // Creates a CameraPosition from the builder
        mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
        return marker;
    }


}
