package com.megafreeapps.speedometer.live.camera.speed.detector.freegps.activities;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlacePicker;
import com.google.android.gms.maps.model.LatLng;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.DbHelper;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.LocaleHelper;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.R;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.util.AppPurchasePref;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.util.Favourite_Places_Model;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.util.PurchasePref;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.util.Utils;

import java.util.ArrayList;
import java.util.List;

public class FavouritePlacesActivity extends AppCompatActivity
{

    int position = 0;
    boolean isFromBackPress = false;
    private Activity context;
    private int PLACE_PICKER_REQUEST = 11;
    private Resources resources;
    private RecyclerView rvItems;
    AdView mAdView;
    private DbHelper dbHelper;
    private List<Favourite_Places_Model> list;
    private Favourite_Places_Adapter placesAdapter;
    private InterstitialAd mInterstitialAd;

    @Override
    protected void attachBaseContext(Context base)
    {
        super.attachBaseContext(LocaleHelper.onAttach(base));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favourite_places);

        AppPurchasePref appPurchasePref = new AppPurchasePref(getApplicationContext());
        if (appPurchasePref.getItemDetail().equals("") && appPurchasePref.getProductId().equals(""))
        {
            mAdView = this.findViewById(R.id.adView);
                mAdView.loadAd(new AdRequest.Builder().build());
                mAdView.setAdListener(new AdListener() {
                    @Override
                    public void onAdLoaded() {
                        super.onAdLoaded();
                        mAdView.setVisibility(View.VISIBLE);
                    }
                });

            mInterstitialAd = new InterstitialAd(this);
            mInterstitialAd.setAdUnitId(getString(R.string.interstitial_ad_id));
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
            mInterstitialAd.setAdListener(new AdListener()
            {
                @Override
                public void onAdClosed()
                {
                    super.onAdClosed();
                    mInterstitialAd.loadAd(new AdRequest.Builder().build());
                    if (isFromBackPress)
                    {

                        finish();
                    }
                    else
                    {
                        onClickListener();
                    }
                }
            });
        }
        context = FavouritePlacesActivity.this;
        dbHelper = new DbHelper(context);
        resources = getResources();
        rvItems = findViewById(R.id.rvItems);
        rvItems.setLayoutManager(new LinearLayoutManager(context));
        list = new ArrayList<>();
        list = dbHelper.GetFavouritePlacesList();
        if (list != null && list.size() > 0)
        {
            placesAdapter = new Favourite_Places_Adapter(context, list);
            rvItems.setAdapter(placesAdapter);
        }
        findViewById(R.id.fab).setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                try
                {
                    PlacePicker.IntentBuilder builder = new PlacePicker.IntentBuilder();
                    startActivityForResult(builder.build(context), PLACE_PICKER_REQUEST);
                }
                catch (GooglePlayServicesRepairableException e)
                {
                    // TODO: Handle the error.
                }
                catch (GooglePlayServicesNotAvailableException e)
                {
                    // TODO: Handle the error.
                }
            }
        });
        SetupToolbar();
    }

    private void SetupToolbar()
    {
        try
        {
            Toolbar toolbar = findViewById(R.id.toolbar);
            setSupportActionBar(toolbar);
            toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
            toolbar.setNavigationOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View v)
                {
                    if (!isFromBackPress && mInterstitialAd != null && mInterstitialAd.isLoaded())
                    {
                        isFromBackPress = true;
                        mInterstitialAd.show();
                    }
                    else
                    {
                        finish();
                    }
                }
            });
        }
        catch (Exception ignored)
        {
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PLACE_PICKER_REQUEST)
        {
            if (resultCode == RESULT_OK && data != null)
            {
                try
                {
                    Place place = PlacePicker.getPlace(context, data);
                    LatLng latLng = place.getLatLng();
                    ContentValues values = new ContentValues();
                    values.put(resources.getString(R.string.TxtDbAddress), place.getAddress() + "");
                    values.put(resources.getString(R.string.TxtDbDate), Utils.GetCustomDate("dd/MM/yyyy"));
                    values.put(resources.getString(R.string.TxtDbTime), Utils.GetCustomDate("hh:mm a"));
                    values.put(resources.getString(R.string.TxtDbName), place.getName() + "");
                    values.put(resources.getString(R.string.TxtDbLatitude), latLng.latitude + "");
                    values.put(resources.getString(R.string.TxtDbLongitude), latLng.longitude + "");

                    if (dbHelper.InsertData(values, resources.getString(R.string.TxtTblPlaces)))
                    {
                        if (list != null && list.size() > 0)
                        {
                            list.add(new Favourite_Places_Model(place.getAddress() + "", place.getName() + "",
                                    Utils.GetCustomDate("dd/MM/yyyy"), Utils.GetCustomDate("hh:mm a"), latLng.latitude + "",
                                    latLng.longitude + ""));
                            placesAdapter.notifyDataSetChanged();
                        }
                        else
                        {
                            list = new ArrayList<>();
                            list.add(new Favourite_Places_Model(place.getAddress() + "", place.getName() + "",
                                    Utils.GetCustomDate("dd/MM/yyyy"), Utils.GetCustomDate("hh:mm a"), latLng.latitude + "",
                                    latLng.longitude + ""));
                            placesAdapter = new Favourite_Places_Adapter(context, list);
                            rvItems.setAdapter(placesAdapter);
                        }
                    }
                }
                catch (Exception ignored)
                {
                }
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.favourite_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
            // action with ID action_refresh was selected
            case R.id.action_clear:
                if (dbHelper != null)
                {
                    dbHelper.DeleteTableData(resources.getString(R.string.TxtTblPlaces));
                }
                if (list != null && list.size() > 0)
                {
                    list.clear();
                }
                else
                {
                    list = new ArrayList<>();
                }
                if (rvItems != null)
                {
                    rvItems.setAdapter(null);
                }
                break;
        }

        return true;
    }

    @Override
    public void onBackPressed()
    {
            isFromBackPress = true;
            super.onBackPressed();

    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mAdView != null) {
            mAdView.resume();
        }

    }

    @Override
    protected void onPause() {

        if (mAdView != null) {
            mAdView.pause();
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (mAdView != null) {
            mAdView.destroy();
        }

        super.onDestroy();
    }



    private void onClickListener()
    {
        try
        {
//                    Uri gmmIntentUri = Uri.parse("google.navigation:q=" + list.get(getAdapterPosition()).Name);
            Favourite_Places_Model favouritePlaces = list.get(position);
            Uri gmmIntentUri;
            if (favouritePlaces.Name.equals(""))
            {
                gmmIntentUri = Uri.parse("https://www.google.com/maps/dir/?api=1&destination=" + favouritePlaces.Latitude + "," +
                        favouritePlaces.Longitude);
            }
            else
            {
                gmmIntentUri = Uri.parse("https://www.google.com/maps/dir/?api=1&destination=" + favouritePlaces.Name);
            }
            Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
            mapIntent.setPackage("com.google.android.apps.maps");
            if (mapIntent.resolveActivity(context.getPackageManager()) != null)
            {
                context.startActivity(mapIntent);
            }
        }
        catch (Exception ignored)
        {
        }
    }

    public class Favourite_Places_Adapter extends RecyclerView.Adapter<Favourite_Places_Adapter.ViewHolder>
    {
        private Activity context;
        private List<Favourite_Places_Model> list;

        Favourite_Places_Adapter(Activity context, List<Favourite_Places_Model> list)
        {
            this.context = context;
            this.list = list;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
        {
            return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.favourite_places_row, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position)
        {
            Favourite_Places_Model favouritePlacesModel = list.get(position);
            if (favouritePlacesModel.Name.equals(""))
            {
                holder.tvAddress.setText(String.valueOf(favouritePlacesModel.Latitude + "," + favouritePlacesModel.Longitude));
            }
            else
            {
                holder.tvAddress.setText(String.valueOf(favouritePlacesModel.Name + "," + list.get(position).Address));
            }
            holder.tvDateTime.setText(String.valueOf("Date:" + favouritePlacesModel.Date + " Time:" + list.get(position).Time));

        }

        @Override
        public int getItemCount()
        {
            return list.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder
        {
            private TextView tvAddress;
            private TextView tvDateTime;

            ViewHolder(View itemView)
            {
                super(itemView);
                tvAddress = itemView.findViewById(R.id.tvAddress);
                tvDateTime = itemView.findViewById(R.id.tvDateTime);

                itemView.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View v)
                    {
                        position = getAdapterPosition();
                        isFromBackPress = false;
                        if (mInterstitialAd != null && mInterstitialAd.isLoaded())
                        {
                            mInterstitialAd.show();
                        }
                        else
                        {
                            onClickListener();
                        }
                    }
                });
            }
        }
    }
}
