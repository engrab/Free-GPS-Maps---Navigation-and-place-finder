package com.megafreeapps.speedometer.live.camera.speed.detector.freegps.activities;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.speech.RecognizerIntent;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.gitonway.lee.niftymodaldialogeffects.lib.NiftyDialogBuilder;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.AppController;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.R;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.adapters.MapTypeAdapter;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.modle.MapItem;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.service.LocationServiceRoute;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.util.DirectionsJSONParser;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.util.PurchasePref;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.util.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

import static com.gitonway.lee.niftymodaldialogeffects.lib.Effectstype.Fliph;
import static com.gitonway.lee.niftymodaldialogeffects.lib.Effectstype.Newspager;
import static com.gitonway.lee.niftymodaldialogeffects.lib.Effectstype.RotateBottom;


public class LiveSpeedoMeterActivity extends AppCompatActivity implements OnMapReadyCallback, View.OnClickListener {


    private ArrayList<MapItem> mMapItemList;

    public static TextView Speedometer;
    public static int maxSpeed = 0;
    static boolean status;
    Geocoder geocoder;
    List<Address> addresses;
    GoogleMap map;
    TextView Speed_Limt, tvMapMode, speedLimit, mapStyle, trafficMode, shareLocation, cityName, mycity;
    ImageView Traffic, Night_Mode;
    ArrayList<LatLng> mMarkerPoints;
    String TAG = "mapactivity";
    boolean mapBusy = false;
    EditText tv_Speedlimit, tv_destinatin;
    Dialog mDialog;
    int VOICE_REQUEST = 12;
    SharedPreferences sharedpreferences;
    FusedLocationProviderClient mFusedLocationClient;
    Activity context;
    int mapType = 1;
    int viewId = 0;
    boolean is3dModEnable = false;
    LocationServiceRoute myService;
    LocationManager locationManager;
    boolean isFromStart = true;
    boolean isTrafficEnable = false;
    boolean isNightModEnable = false;
    boolean isFromBackPress = false;
    private AdView mAdView;
    private MapStyleOptions nightMapStyleOptions, standradMapStyleOptions;
    private AutoCompleteTextView completeTextView;
    private InterstitialAd mInterstitialAd;
    Location location;
    private ServiceConnection sc = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            LocationServiceRoute.LocalBinder binder = (LocationServiceRoute.LocalBinder) service;
            myService = binder.getService();
            status = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            status = false;
        }
    };

    LocationCallback mLocationCallback = new LocationCallback() {
        @Override
        public void onLocationResult(LocationResult locationResult) {
            if (locationResult != null) {
                List<Location> locationList = locationResult.getLocations();
                if (locationList != null && locationList.size() > 0) {
                    //The last location in the list is the newest
                    location = locationList.get(locationList.size() - 1);

                    double lat = location.getLatitude();
                    double lng = location.getLongitude();

                    Geocoder geoCoder = new Geocoder(LiveSpeedoMeterActivity.this, Locale.getDefault());
                    StringBuilder builder = new StringBuilder();
                    try {
                        List<Address> address = geoCoder.getFromLocation(lat, lng, 1);
                        int maxLines = address.get(0).getMaxAddressLineIndex();
                        for (int i = 0; i < maxLines; i++) {
                            String addressStr = address.get(0).getAddressLine(i);
                            builder.append(addressStr);
                            builder.append(" ");
                        }

                        String fnialAddress = builder.toString(); //This is the complete address.

//                        latituteField.setText(String.valueOf(lat));
//                        longitudeField.setText(String.valueOf(lng));
                        cityName.setText(fnialAddress); //This will display the final address.

                    } catch (IOException e) {
                        // Handle IOException
                    } catch (NullPointerException e) {
                        // Handle NullPointerException
                    }
                    AppController.getAppInstance().setGlobalLocation(location);

                }
            }
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_live_speedo_meter);
        showSpeedDialog();
        startLocationUpdates();
        context = LiveSpeedoMeterActivity.this;
        Typeface font = Typeface.createFromAsset(context.getAssets(), "franklingothic.ttf");

        initList();

        Spinner spinnerMapType = findViewById(R.id.sp_map_type);
        MapTypeAdapter mMapTypeAdapter = new MapTypeAdapter(this, mMapItemList);
        spinnerMapType.setAdapter(mMapTypeAdapter);

        spinnerMapType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                MapItem clickedItem = (MapItem) parent.getItemAtPosition(position);
                String clickedMapTypeName = clickedItem.getmMapName();
//                int clickedMapTypeId = clickedItem.getmMapImage();
//                Toast.makeText(context, clickedMapTypeName+" selelcted", Toast.LENGTH_SHORT).show();
//                Toast.makeText(context, clickedMapTypeId+"", Toast.LENGTH_SHORT).show();

                if (map != null) {
                    switch (clickedMapTypeName) {

                        case "Normal":
                            map.setMapType(GoogleMap.MAP_TYPE_NORMAL);
                            break;
                        case "Satellite":
                            map.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
                            break;
                        case "Terrain":
                            map.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
                            break;
                        case "Hybrid":
                            map.setMapType(GoogleMap.MAP_TYPE_HYBRID);
                            break;
                    }
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        PurchasePref purchasePref = new PurchasePref(getApplicationContext());
        if (purchasePref.getItemDetail().equals("") && purchasePref.getProductId().equals("")) {
            mAdView = this.findViewById(R.id.adView);
            mAdView.loadAd(new AdRequest.Builder().build());
            mAdView.setAdListener(new AdListener() {


                @Override
                public void onAdLoaded() {
                    super.onAdLoaded();
                    mAdView.setVisibility(View.VISIBLE);
                }
            });
            mInterstitialAd = new InterstitialAd(this);
            mInterstitialAd.setAdUnitId(getString(R.string.interstitial_ad_id));
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
            mInterstitialAd.setAdListener(new AdListener() {

                @Override
                public void onAdFailedToLoad(int i) {
                    super.onAdFailedToLoad(i);
                }

                @Override
                public void onAdClosed() {
                    super.onAdClosed();
                    if (isFromBackPress) {
                        ExitDialog();
                    } else {
                        mInterstitialAd.loadAd(new AdRequest.Builder().build());
                        clickListeners();
                    }

                }
            });
        }
        nightMapStyleOptions = MapStyleOptions.loadRawResourceStyle(context, R.raw.nightmode_map);
        standradMapStyleOptions = MapStyleOptions.loadRawResourceStyle(context, R.raw.standard_map);


        Speedometer = findViewById(R.id.iv_speedometr);
        Speed_Limt = findViewById(R.id.tv_limit);

        tvMapMode = findViewById(R.id.tv_map_mode);
        tvMapMode.setTypeface(font);

        speedLimit = findViewById(R.id.tv_speed_limit);
        speedLimit.setTypeface(font);

        mapStyle = findViewById(R.id.tv_map_style);
        mapStyle.setTypeface(font);

        trafficMode = findViewById(R.id.tv_traffic_mode);
        trafficMode.setTypeface(font);

        shareLocation = findViewById(R.id.tv_share_location);
        shareLocation.setTypeface(font);

        cityName = findViewById(R.id.tv_city_name);
        cityName.setTypeface(font);
        mycity = findViewById(R.id.tv_my_city);
        mycity.setTypeface(font);


        Traffic = findViewById(R.id.iv_traffic);
        Traffic.setOnClickListener(this);
        Night_Mode = findViewById(R.id.night_mode);
        Night_Mode.setOnClickListener(this);
        tv_destinatin = findViewById(R.id.Destination);
        findViewById(R.id.iv_share_location).setOnClickListener(this);
        sharedpreferences = getSharedPreferences("AddressPref", Context.MODE_PRIVATE);

        tv_Speedlimit = findViewById(R.id.speed_limit);

//        findViewById(R.id.iv_search).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                showDestinationDialog();
//            }
//        });

        findViewById(R.id.rl).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isFromStart = false;
                showSpeedDialog();

            }
        });
        Speed_Limt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isFromStart = false;
                showSpeedDialog();
            }
        });

//        mapMode.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if (map != null) {
//                    if (!is3dModEnable) {
//                        is3dModEnable = true;
//                        map.setMapType(GoogleMap.MAP_TYPE_NORMAL);
//                        mapMode.setImageResource(R.drawable.ic_3d_map);
//                    } else if (is3dModEnable) {
//                        is3dModEnable = false;
//                        map.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
//                        mapMode.setImageResource(R.drawable.ic_2d_map);
//                    }
//
//                }
//                is3dModEnable = false;
//            }
//        });
        geocoder = new Geocoder(this, Locale.getDefault());

        int mapStatus = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(getBaseContext());

        if (mapStatus != ConnectionResult.SUCCESS) {
            int requestCode = 10;
            Dialog dialog = GoogleApiAvailability.getInstance().getErrorDialog(this, mapStatus, requestCode);
            dialog.show();
        } else {
            SupportMapFragment fm = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
            if (fm != null) {
                fm.getMapAsync(this);
            }
        }

        maxSpeed = sharedpreferences.getInt("maxSpeed", 80);

        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (locationManager != null && !locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            //Toast.makeText(this, "GPS is Enabled in your devide", Toast.LENGTH_SHORT).show();
            showGPSDisabledAlertToUser();
            return;
        }
        if (!status) {
            bindService();
        }

//        findViewById(R.id.iv_play).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                showSpeedDialog();
//
//                findViewById(R.id.iv_pause).setVisibility(View.VISIBLE);
//                findViewById(R.id.iv_play).setVisibility(View.GONE);
//
//            }
//        });
//        findViewById(R.id.iv_pause).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                findViewById(R.id.iv_pause).setVisibility(View.GONE);
//                findViewById(R.id.iv_play).setVisibility(View.VISIBLE);
//
//            }
//        });
    }


    void bindService() {
//        if (status)
//        {
//            return;
//        }
//        bindService(new Intent(getApplicationContext(), LocationServiceRoute.class), sc, BIND_AUTO_CREATE);
//        status = true;
        startService(new Intent(context, LocationServiceRoute.class));
    }

    private void showGPSDisabledAlertToUser() {
        new AlertDialog.Builder(this)
                .setMessage("Enable GPS to use application")
                .setCancelable(false)
                .setPositiveButton("Enable GPS",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                Intent callGPSSettingIntent = new Intent(
                                        android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                                startActivity(callGPSSettingIntent);
                            }
                        })
                .setNegativeButton("Cancel",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        })
                .show();
    }

    void unbindService() {
//        if (!status)
//        {
//            return;
//        }
        try {

//            if (sc != null)
//            {
//                unbindService(sc);
//                status = false;
//            }
            stopService(new Intent(context, LocationServiceRoute.class));

//            Intent intent = new Intent(context, LocationServiceRoute.class);
//            intent.setAction(LocationServiceRoute.STOP_SERVICE);
//            startService(intent);
        } catch (Exception ignored) {
        }
    }

    private void initList() {
        mMapItemList = new ArrayList<>();
        mMapItemList.add(new MapItem("Normal", R.drawable.ic_normal));
        mMapItemList.add(new MapItem("Satellite", R.drawable.ic_satellite));
        mMapItemList.add(new MapItem("Terrain", R.drawable.ic_terrain));
        mMapItemList.add(new MapItem("Hybrid", R.drawable.ic_hybrid));
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == VOICE_REQUEST && data != null) {
                String address = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS).get(0);
                try {
                    if (address == null || address.equals("")) {
                        Toast.makeText(this, "Address not found\nPlease Try Again", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    completeTextView.setText(address);
                    completeTextView.setSelection(completeTextView.length());

                } catch (Exception ignored) {

                }
            }
        }

    }

    private void showSpeedDialog() {
        try {
            View view = LayoutInflater.from(LiveSpeedoMeterActivity.this).inflate(R.layout.speedlimit_dialog, null, false);
            final EditText speedLimit = view.findViewById(R.id.speed_limit);
            speedLimit.setText(maxSpeed + "");
            speedLimit.setSelection(speedLimit.length());
//            speedLimit.setSelected(true);
//            speedLimit.setSelectAllOnFocus(true);
            view.findViewById(R.id.go).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (speedLimit.getText().toString().equals("")) {
                        Toast.makeText(LiveSpeedoMeterActivity.this, "Please enter speedometer limit", Toast.LENGTH_SHORT).show();
                    } else {
                        try {
                            maxSpeed = Integer.parseInt(speedLimit.getText().toString());
                        } catch (Exception e) {
                            String speed = speedLimit.getText().toString();
                            if (speed.contains(".")) {
                                speed = speed.substring(0, speed.indexOf(".") - 1);
                            }
                            maxSpeed = Integer.parseInt(speed);
                        }
                        SharedPreferences.Editor editor = sharedpreferences.edit();
                        editor.putInt("maxSpeed", maxSpeed);
                        editor.apply();
                        Speed_Limt.setText(maxSpeed + "");
                        mDialog.dismiss();
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                            if (isFromStart && !Objects.requireNonNull(sharedpreferences.getString("address", "")).equals("")) {
                                showLoadPreviousDialog(sharedpreferences.getString("address", ""));
                            }
                        }
                    }
                }
            });

            mDialog = new Dialog(LiveSpeedoMeterActivity.this, R.style.MaterialDialogSheet);
            mDialog.setContentView(view);
            mDialog.setCancelable(true);
            mDialog.setCanceledOnTouchOutside(false);
            if (mDialog.getWindow() != null) {
                mDialog.getWindow().setLayout(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                mDialog.getWindow().setGravity(Gravity.CENTER);
            }
            mDialog.show();
        } catch (Exception ignored) {
        }
    }

    private void showSpeedDialogNew() {
        View view = LayoutInflater.from(LiveSpeedoMeterActivity.this).inflate(R.layout.speedlimit_dialoge_new, null, false);
        final EditText speedLimit = view.findViewById(R.id.speed_limit);
        speedLimit.setText(maxSpeed + "");
        speedLimit.setSelection(speedLimit.length());
        NiftyDialogBuilder dialogBuilder = NiftyDialogBuilder.getInstance(this);
        dialogBuilder
                .withTitle("Speed Limite")                                  //.withTitle(null)  no title
                .withTitleColor("#FFFFFF")                                  //def
                .withDividerColor("#11000000")                              //def
                .withMessage("Set Your Speed Limit")                     //.withMessage(null)  no Msg
                .withMessageColor("#FFFFFFFF")                              //def  | withMessageColor(int resid)
                .withDialogColor("#FFE74C3C")                               //def  | withDialogColor(int resid)
                .withIcon(getResources().getDrawable(R.mipmap.ic_launcher))
                .withDuration(700)                                          //def
                .withEffect(Fliph)                                         //def Effectstype.Slidetop
                .withButton1Text("OK")                                       //def gone
                .isCancelableOnTouchOutside(true)                           //def    | isCancelable(true)
                .setCustomView(view, LiveSpeedoMeterActivity.this)         //.setCustomView(View or ResId,context)
                .setButton1Click(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (speedLimit.getText().toString().equals("")) {
                            Toast.makeText(LiveSpeedoMeterActivity.this, "Please enter speedometer limit", Toast.LENGTH_SHORT).show();
                        } else {
                            try {
                                maxSpeed = Integer.parseInt(speedLimit.getText().toString());
                            } catch (Exception e) {
                                String speed = speedLimit.getText().toString();
                                if (speed.contains(".")) {
                                    speed = speed.substring(0, speed.indexOf(".") - 1);
                                }
                                maxSpeed = Integer.parseInt(speed);
                            }
                            SharedPreferences.Editor editor = sharedpreferences.edit();
                            editor.putInt("maxSpeed", maxSpeed);
                            editor.apply();
                            Speed_Limt.setText(maxSpeed + "");
                            mDialog.dismiss();
                            if (isFromStart && !sharedpreferences.getString("address", "").equals("")) {
                                showLoadPreviousDialog(sharedpreferences.getString("address", ""));
                            }
                        }

                        Toast.makeText(v.getContext(), "i'm btn1", Toast.LENGTH_SHORT).show();
                    }
                })
                .show();


    }

    @SuppressLint("SetTextI18n")
    private void showLoadPreviousDialog(final String destination) {
        try {
            View view = LayoutInflater.from(LiveSpeedoMeterActivity.this).inflate(R.layout.showloadprevous_dialog, null, false);
            final TextView tvDestination = view.findViewById(R.id.tvMessage);
            tvDestination.setText("Destination: " + destination);
            view.findViewById(R.id.btnload).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mDialog.dismiss();
                    setLatLng(destination);
                }
            });
            view.findViewById(R.id.btncancel).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mDialog.dismiss();

                }
            });

            mDialog = new Dialog(LiveSpeedoMeterActivity.this, R.style.MaterialDialogSheet);
            mDialog.setContentView(view);
            mDialog.setCancelable(true);
            mDialog.setCanceledOnTouchOutside(false);
            if (mDialog.getWindow() != null) {
                mDialog.getWindow().setLayout(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                mDialog.getWindow().setGravity(Gravity.CENTER);
            }
            mDialog.show();
        } catch (Exception ignored) {
        }
    }

    @SuppressLint("SetTextI18n")
    private void showLoadPreviousDialogNew(final String destination) {

        View view = LayoutInflater.from(LiveSpeedoMeterActivity.this).inflate(R.layout.showloadprevous_dialog_new, null, false);
        final TextView tvDestination = view.findViewById(R.id.tvMessage);
        tvDestination.setText("Destination: " + destination);

        NiftyDialogBuilder dialogBuilder = NiftyDialogBuilder.getInstance(this);

        dialogBuilder
                .withTitle(getString(R.string.reload_previous_path))                                  //.withTitle(null)  no title
                .withTitleColor("#FFFFFF")                                  //def
                .withDividerColor("#11000000")                              //def
                .withMessage("Destination: ")                     //.withMessage(null)  no Msg
                .withMessageColor("#FFFFFFFF")                              //def  | withMessageColor(int resid)
                .withDialogColor("#FFE74C3C")                               //def  | withDialogColor(int resid)
                .withIcon(getResources().getDrawable(R.mipmap.ic_launcher))
                .withDuration(700)                                          //def
                .withEffect(Newspager)                                         //def Effectstype.Slidetop
                .withButton1Text(getString(R.string.cancel))                                      //def gone
                .withButton2Text(getString(R.string.load))                                  //def gone
                .isCancelableOnTouchOutside(true)                           //def    | isCancelable(true)
                .setCustomView(view, LiveSpeedoMeterActivity.this)    //.setCustomView(View or ResId,context)
                .setButton1Click(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mDialog.dismiss();

//                        Toast.makeText(v.getContext(), "i'm btn1", Toast.LENGTH_SHORT).show();
                    }
                })
                .setButton2Click(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mDialog.dismiss();
                        setLatLng(destination);
//                        Toast.makeText(v.getContext(),"i'm btn2",Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }

    private void showDestinationDialog() {
        try {
            View view = LayoutInflater.from(LiveSpeedoMeterActivity.this).inflate(R.layout.destination_dialog, null, false);
            view.findViewById(R.id.go).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (completeTextView.getText().toString().equals("")) {
                        Toast.makeText(LiveSpeedoMeterActivity.this, "Please enter destination first", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    setLatLng(completeTextView.getText().toString());
                    mDialog.dismiss();
                }
            });
            view.findViewById(R.id.voice).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try {
                        if (getPackageManager().queryIntentActivities(new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH), 0)
                                .size() != 0) {
                            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                            intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Where you want to go! Speak Now!");
                            intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
                            startActivityForResult(intent, VOICE_REQUEST);
                        } else {
                            AlertDialog alertDialog = new AlertDialog.Builder(LiveSpeedoMeterActivity.this).create();
                            alertDialog.setTitle("Warning!");
                            alertDialog.setMessage("Voice Recognition Engine on Your Device is Not Active");
                            alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                            alertDialog.show();
                        }
                    } catch (Exception ignored) {
                    }
                }
            });
            completeTextView = view.findViewById(R.id.Destination);
            completeTextView.setAdapter(new Filter(LiveSpeedoMeterActivity.this, LiveSpeedoMeterActivity.this, R.layout.adp_auto_complete));
            mDialog = new Dialog(LiveSpeedoMeterActivity.this, R.style.MaterialDialogSheet);
            mDialog.setContentView(view);
            mDialog.setCancelable(true);
            mDialog.setCanceledOnTouchOutside(false);
            if (mDialog.getWindow() != null) {
                mDialog.getWindow().setLayout(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                mDialog.getWindow().setGravity(Gravity.CENTER);
            }
            mDialog.show();
        } catch (Exception ignored) {
        }
    }

    private void showDestinationDialogNew() {
        try {
            View view = LayoutInflater.from(LiveSpeedoMeterActivity.this).inflate(R.layout.destination_dialog_new, null, false);
            view.findViewById(R.id.go).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (completeTextView.getText().toString().equals("")) {
                        Toast.makeText(LiveSpeedoMeterActivity.this, "Please enter destination first", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    setLatLng(completeTextView.getText().toString());
                    mDialog.dismiss();
                }
            });
            view.findViewById(R.id.voice).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try {
                        if (getPackageManager().queryIntentActivities(new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH), 0)
                                .size() != 0) {
                            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                            intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Where you want to go! Speak Now!");
                            intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
                            startActivityForResult(intent, VOICE_REQUEST);
                        } else {
                            AlertDialog alertDialog = new AlertDialog.Builder(LiveSpeedoMeterActivity.this).create();
                            alertDialog.setTitle("Warning!");
                            alertDialog.setMessage("Voice Recognition Engine on Your Device is Not Active");
                            alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                            alertDialog.show();
                        }
                    } catch (Exception ignored) {
                    }
                }
            });
            completeTextView = view.findViewById(R.id.Destination);
            completeTextView.setAdapter(new Filter(LiveSpeedoMeterActivity.this, LiveSpeedoMeterActivity.this, R.layout.adp_auto_complete));
            mDialog = new Dialog(LiveSpeedoMeterActivity.this, R.style.MaterialDialogSheet);
            mDialog.setContentView(view);
            mDialog.setCancelable(true);
            mDialog.setCanceledOnTouchOutside(false);
            if (mDialog.getWindow() != null) {
                mDialog.getWindow().setLayout(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                mDialog.getWindow().setGravity(Gravity.CENTER);
            }
            mDialog.show();
        } catch (Exception ignored) {
        }
    }

    public ArrayList getOptions(String str) {
        HttpURLConnection httpURLConnection;
        Throwable th;
        HttpURLConnection httpURLConnection2 = null;
        StringBuilder stringBuilder = new StringBuilder();
        try {
            String stringBuilder2 = "https://maps.googleapis.com/maps/api/place/autocomplete/json" +
                    "?key=AIzaSyC9o5u9HttEG8Mlonxn1qyZHqLPASJEvA8" +
                    "&input=" + URLEncoder.encode(str, "utf8");
            httpURLConnection = (HttpURLConnection) new URL(stringBuilder2).openConnection();
            try {
                InputStreamReader inputStreamReader = new InputStreamReader(httpURLConnection.getInputStream());
                char[] cArr = new char[1024];
                while (true) {
                    int read = inputStreamReader.read(cArr);
                    if (read == -1) {
                        break;
                    }
                    stringBuilder.append(cArr, 0, read);
                }
                httpURLConnection.disconnect();
                try {
                    JSONArray jSONArray = new JSONObject(stringBuilder.toString()).getJSONArray("predictions");
                    ArrayList arrayList = new ArrayList(jSONArray.length());
                    int i = 0;
                    while (i < jSONArray.length()) {
                        try {
                            System.out.println(jSONArray.getJSONObject(i).getString("description"));
                            System.out.println("============================================================");
                            arrayList.add(jSONArray.getJSONObject(i).getString("description"));
                            i++;
                        } catch (JSONException e) {
                            return arrayList;
                        }
                    }
                    return arrayList;
                } catch (JSONException e2) {
                    return null;
                }
            } catch (MalformedURLException e3) {
                httpURLConnection.disconnect();
                return null;
            } catch (IOException e4) {
                httpURLConnection.disconnect();
                return null;
            } catch (Throwable th2) {
                httpURLConnection2 = httpURLConnection;
                th = th2;
                if (httpURLConnection2 != null) {
                    httpURLConnection2.disconnect();
                }
                throw th;
            }
        } catch (MalformedURLException e5) {
            return null;
        } catch (IOException e6) {
            return null;
        } catch (Throwable th4) {
            if (httpURLConnection2 != null) {
                httpURLConnection2.disconnect();
            }

        }

        return null;
    }


    private String getDirectionsUrl(LatLng origin, LatLng dest) {

        String str_origin = "origin=" + origin.latitude + "," + origin.longitude;
        String str_dest = "destination=" + dest.latitude + "," + dest.longitude;
        String sensor = "sensor=false";
        String parameters = str_origin + "&" + str_dest + "&" + sensor;
        String output = "json";
        return "https://maps.googleapis.com/maps/api/directions/" + output + "?" + parameters;
    }

    /**
     * A method to download json data from url
     */
    private String downloadUrl(String strUrl) throws IOException {
        String data = "";
        InputStream iStream = null;
        HttpURLConnection urlConnection = null;
        try {
            URL url = new URL(strUrl);

            // Creating an http connection to communicate with url
            urlConnection = (HttpURLConnection) url.openConnection();

            // Connecting to url
            urlConnection.connect();

            // Reading data from url
            iStream = urlConnection.getInputStream();

            BufferedReader br = new BufferedReader(new InputStreamReader(iStream));

            StringBuilder sb = new StringBuilder();

            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }

            data = sb.toString();

            br.close();

        } catch (Exception e) {
            Log.d(TAG, e.toString());
        } finally {
            if (iStream != null) {
                iStream.close();
            }
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
        }
        return data;
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        // Initializing
        mMarkerPoints = new ArrayList<>();
        googleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        map = googleMap;
        if (AppController.getAppInstance().getGlobalLocation() != null) {
            Location location = AppController.getAppInstance().getGlobalLocation();
            if (location != null) {
                LatLng point = new LatLng(location.getLatitude(), location.getLongitude());
                map.moveCamera(CameraUpdateFactory.newLatLng(point));
                map.animateCamera(CameraUpdateFactory.zoomTo(15));

            }
        }

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        map.setMyLocationEnabled(true);
    }

    private void drawMarker(LatLng point) {
        if (map == null) {
            return;
        }

        mMarkerPoints.add(point);
        MarkerOptions options = new MarkerOptions();
        options.position(point);
        options.title(getAddress(point));
        if (mMarkerPoints.size() == 1) {
            options.icon(BitmapDescriptorFactory.fromResource(R.drawable.my_location_marker));
        } else if (mMarkerPoints.size() == 2) {
            options.icon(BitmapDescriptorFactory.fromResource(R.drawable.destination));
        }
        map.addMarker(options);
    }

    @Override
    protected void onPause() {
        if (mAdView != null) {
            mAdView.pause();
        }
        super.onPause();
    }

    @Override
    protected void onResume() {
        if (mAdView != null) {
            mAdView.resume();
        }
        super.onResume();
    }

    @Override
    protected void onStop() {
        super.onStop();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mAdView != null) {
            mAdView.destroy();
        }
    }

    private String getAddress(LatLng location) {
        try {
            addresses = geocoder.getFromLocation(location.latitude, location.longitude, 1); // Here 1 represent max location
            if (addresses != null) {
                Address returnedAddress = addresses.get(0);
                StringBuilder strReturnedAddress = new StringBuilder();
                if (returnedAddress.getMaxAddressLineIndex() == 0) {
                    if (returnedAddress.getAddressLine(0) != null && !returnedAddress.getAddressLine(0).equals("")) {
                        strReturnedAddress.append(returnedAddress.getAddressLine(0)).append("\n");
                    }
                } else {
                    for (int i = 0; i < returnedAddress.getMaxAddressLineIndex(); i++) {
                        strReturnedAddress.append(returnedAddress.getAddressLine(i)).append("\n");

                    }
                }
                return strReturnedAddress.toString();
//                Log.w(TAG, "My Current loction address" + strReturnedAddress.toString());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }

    private void setLatLng(String address) {
        try {
            if (address == null || address.equals("")) {
                Toast.makeText(this, "Address not found\nPlease Try Again", Toast.LENGTH_SHORT).show();
                return;
            }
            try {
                List<Address> addresses = geocoder.getFromLocationName(address, 1);
                if (addresses != null) {

                    Address locationAddress = addresses.get(0);
                    if (AppController.getAppInstance().getGlobalLocation() == null) {
                        Toast.makeText(this, "Starting point not found", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (map == null) {
                        return;
                    }
                    if (locationAddress == null) {
                        Toast.makeText(this, "Address not found\nPlease Try Again", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    SharedPreferences.Editor editor = sharedpreferences.edit();
                    editor.putString("address", address);
                    editor.apply();
                    Location location = AppController.getAppInstance().getGlobalLocation();
                    LatLng orign = new LatLng(location.getLatitude(), location.getLongitude());
                    drawMarker(orign);
                    LatLng dest = new LatLng(locationAddress.getLatitude(), locationAddress.getLongitude());
                    drawMarker(dest);
                    String url = getDirectionsUrl(orign, dest);
                    new DownloadTask().execute(url);
                } else {
                    Toast.makeText(this, "Address not found\nPlease Try Again", Toast.LENGTH_SHORT).show();
                    Log.w("", "My Current loction address,No Address returned!");
                }
            } catch (Exception e) {
                e.printStackTrace();
                Log.w("", "My Current loction address,Canont get Address!");
            }

        } catch (Exception ignored) {

        }
    }

    private void ExitDialog() {

        try {
            View view = LayoutInflater.from(LiveSpeedoMeterActivity.this).inflate(R.layout.notification_dialog, null, false);
            view.findViewById(R.id.btnAccept).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try {

                        mDialog.dismiss();
                        finish();
                    } catch (Exception ignored) {
                    }

                }
            });
            view.findViewById(R.id.btnstop).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
//                    if (status)
//                    {
                    unbindService();
//                    }
                    mDialog.dismiss();
                    finish();
                }
            });


            mDialog = new Dialog(LiveSpeedoMeterActivity.this, R.style.MaterialDialogSheet);
            mDialog.setContentView(view);
            mDialog.setCancelable(true);
            mDialog.setCanceledOnTouchOutside(false);
            if (mDialog.getWindow() != null) {
                mDialog.getWindow().setLayout(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                mDialog.getWindow().setGravity(Gravity.CENTER);
            }
            mDialog.show();
        } catch (Exception ignored) {
        }
    }


    private void clickListeners() {
        switch (viewId) {
            case R.id.iv_traffic:
                if (isTrafficEnable) {
                    isTrafficEnable = false;
                    Traffic.setImageResource(R.drawable.ic_traffic);
                    if (map != null) {
                        map.setTrafficEnabled(false);
                    }
                } else {
                    isTrafficEnable = true;
                    Traffic.setImageResource(R.drawable.ic_traffic_off);
                    if (map != null) {
                        map.setTrafficEnabled(true);
                    }
                }
                break;
            case R.id.night_mode:
                if (isNightModEnable) {
                    isNightModEnable = false;
                    Night_Mode.setImageResource(R.drawable.day_mode);
                    if (map != null) {
                        map.setMapStyle(standradMapStyleOptions);
                    }
                } else {
                    isNightModEnable = true;
                    Night_Mode.setImageResource(R.drawable.nightmode);
                    if (map != null) {
                        map.setMapStyle(nightMapStyleOptions);
                    }
                }
                break;

            case R.id.iv_share_location:
            case R.id.tv_share_location:
            case R.id.ll_share_location:
                if (location == null) {
                    Toast.makeText(LiveSpeedoMeterActivity.this, "Please Wait", Toast.LENGTH_SHORT).show();
                    return;
                }
                Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                sharingIntent.setType("text/plain");
                sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "");
                sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, "https://maps.google.com/maps?q=loc:"
                        + location.getLatitude() + "," + location.getLongitude());
                if (sharingIntent.resolveActivity(context.getPackageManager()) != null) {

                    startActivity(Intent.createChooser(sharingIntent, getResources().getString(R.string.txt_share_location_via)));
                }
                break;

        }
    }

    @Override
    public void onClick(View view) {

        isFromBackPress = false;
        viewId = view.getId();
        if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
            mInterstitialAd.show();
        } else {
            clickListeners();
        }
    }

    public void onBackPressed() {

        isFromBackPress = true;
        ExitDialog();
    }

    class Filter extends ArrayAdapter implements Filterable {
        LiveSpeedoMeterActivity drawPath;
        private ArrayList arrayList;

        Filter(LiveSpeedoMeterActivity routeHome, Context context, int i) {
            super(context, i);
            this.drawPath = routeHome;

        }

        String m13046a(int i) {
            return this.arrayList.get(i).toString();
        }

        public int getCount() {
            return this.arrayList.size();
        }

        @NonNull
        public android.widget.Filter getFilter() {
            return new filterClass(this);
        }

        public /* synthetic */ Object getItem(int i) {
            return m13046a(i);
        }

        class filterClass extends android.widget.Filter {
            Filter filter;

            filterClass(Filter filter) {
                this.filter = filter;
            }

            protected FilterResults performFiltering(CharSequence charSequence) {
                FilterResults filterResults = new FilterResults();
                if (charSequence != null) {
                    this.filter.arrayList = this.filter.drawPath.getOptions(charSequence.toString());
                    if (this.filter.arrayList != null) {
                        filterResults.values = this.filter.arrayList;
                        filterResults.count = this.filter.arrayList.size();
                    } else {
                        filterResults.values = new ArrayList<>();
                        filterResults.count = 0;

                    }

                }
                return filterResults;
            }

            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                if (filterResults != null && filterResults.count > 0) {
                    this.filter.notifyDataSetChanged();
                } else {
                    this.filter.notifyDataSetInvalidated();
                }
            }
        }
    }

    /**
     * A class to download data from Google Directions URL
     */
    @SuppressLint("StaticFieldLeak")
    private class DownloadTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... url) {

            Log.d(TAG, "DownloadTask doInBackground: ");
            String data = "";

            try {
                data = downloadUrl(url[0]);
            } catch (Exception e) {
                Log.d("Background Task", e.toString());
            }
            return data;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            Log.d(TAG, "DownloadTask onPostExecute: ");
            new ParserTask().execute(result);
        }
    }

    /**
     * A class to parse the Google Directions in JSON format
     */
    @SuppressLint("StaticFieldLeak")
    private class ParserTask extends AsyncTask<String, Integer, List<List<HashMap<String, String>>>> {

        @Override
        protected List<List<HashMap<String, String>>> doInBackground(String... jsonData) {
            Log.d(TAG, "ParserTask doInBackground: ");
            JSONObject jObject;
            List<List<HashMap<String, String>>> routes = null;
            try {
                jObject = new JSONObject(jsonData[0]);
                // Starts parsing data
                routes = new DirectionsJSONParser().parse(jObject);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return routes;
        }

        // Executes in UI thread, after the parsing process
        @Override
        protected void onPostExecute(List<List<HashMap<String, String>>> result) {
            try {
                if (map == null) {
                    return;
                }
                Log.d(TAG, "ParserTask onPostExecute: ");
                System.gc();
                ArrayList<LatLng> points;
                PolylineOptions lineOptions = null;

                // Traversing through all the routes
                if (result != null && result.size() > 0) {
                    for (int i = 0; i < result.size(); i++) {
                        points = new ArrayList<>();
                        lineOptions = new PolylineOptions();

                        // Fetching i-th route
                        List<HashMap<String, String>> path = result.get(i);
                        if (path != null && path.size() > 0) {
                            // Fetching all the points in i-th route
                            for (int j = 0; j < path.size(); j++) {
                                HashMap<String, String> point = path.get(j);
                                if (point != null) {
                                    double lat = Double.parseDouble(point.get("lat"));
                                    double lng = Double.parseDouble(point.get("lng"));

                                    LatLng position = new LatLng(lat, lng);
                                    points.add(position);
                                }
                            }
                        }

                        if (points.size() > 0) {
                            // Adding all the points in the route to LineOptions
                            lineOptions.addAll(points);
                            lineOptions.width(5);
                            lineOptions.color(Color.GREEN);
                        }

                    }
                }

                if (lineOptions != null) {
                    // Drawing polyline in the Google Map for the i-th route
                    map.addPolyline(lineOptions);
                }
                mapBusy = false;
            } catch (Exception ignored) {
            }
        }
    }

    protected void startLocationUpdates() {
        try {
            LocationRequest mLocationRequest = LocationRequest.create()
                    .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                    .setInterval(Utils.UPDATE_INTERVAL)
                    .setFastestInterval(Utils.FASTEST_INTERVAL);
            mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
            if (mLocationCallback != null && mFusedLocationClient != null && mLocationRequest != null) {
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return;
                }
                mFusedLocationClient.requestLocationUpdates(
                        mLocationRequest, mLocationCallback, null);
            }
        } catch (SecurityException ignored) {
        }
    }

}



