package com.megafreeapps.speedometer.live.camera.speed.detector.freegps.activities;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.anjlab.android.iab.v3.BillingProcessor;
import com.anjlab.android.iab.v3.Constants;
import com.anjlab.android.iab.v3.TransactionDetails;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.BuildConfig;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.R;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.analogSpeedometer.MainActivitySpeedometer;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.compass.CompassActivity;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.util.PurchasePref;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    int viewId = 0;
    AdView mAdView;
    InterstitialAd mInterstitialAd;
    private Dialog mDialog;

    BillingProcessor bp;
    ImageView ivRemoveAd;
    Activity context;

    TextView speedTest, rateUs, shareApp, moreApp, privacyPloicy, exitApp;

    private void Init() {

        Typeface font = Typeface.createFromAsset(context.getAssets(), "franklingothic.ttf");

        findViewById(R.id.iv_start).setOnClickListener(this);
        speedTest = findViewById(R.id.tv_speed_test);
        speedTest.setTypeface(font);
        speedTest.setOnClickListener(this);
        findViewById(R.id.tv_speed_test_click).setOnClickListener(this);

        rateUs = findViewById(R.id.tv_rate_us);
        rateUs.setTypeface(font);
        rateUs.setOnClickListener(this);
        shareApp = findViewById(R.id.tv_share_app);
        shareApp.setTypeface(font);
        shareApp.setOnClickListener(this);
        findViewById(R.id.tv_share_app_click).setOnClickListener(this);
        moreApp = findViewById(R.id.tv_more_apps);
        moreApp.setTypeface(font);
        moreApp.setOnClickListener(this);
        findViewById(R.id.tv_more_ap_click).setOnClickListener(this);
        privacyPloicy = findViewById(R.id.tv_privacy_policy);
        privacyPloicy.setTypeface(font);
        privacyPloicy.setOnClickListener(this);
        findViewById(R.id.tv_privacy_policy_click).setOnClickListener(this);
        exitApp = findViewById(R.id.tv_exit_app);
        exitApp.setTypeface(font);
        exitApp.setOnClickListener(this);
        findViewById(R.id.tv_exit_app_click).setOnClickListener(this);
        ivRemoveAd = findViewById(R.id.ivRemoveAd);

    }

    private PurchasePref purchasePref;
    BillingProcessor.IBillingHandler billingHandler = new BillingProcessor.IBillingHandler() {
        @Override
        public void onProductPurchased(@NonNull String productId, @Nullable TransactionDetails details) {
            updateView();
            purchasePref.setProductId(productId);
            if (details != null) {
                purchasePref.setItemDetails(details.toString());
            }
        }

        @Override
        public void onPurchaseHistoryRestored() {
            updateView();
        }

        @Override
        public void onBillingError(int errorCode, @Nullable Throwable error) {

            switch (errorCode) {
                case Constants.BILLING_RESPONSE_RESULT_USER_CANCELED:
                    showToast("Transaction cancel!");
                    break;
                case Constants.BILLING_RESPONSE_RESULT_SERVICE_UNAVAILABLE:
                    showToast("Network connection is down!");

                    break;
                case Constants.BILLING_RESPONSE_RESULT_BILLING_UNAVAILABLE:
                    showToast("This version is not supported for purchase this item!");

                    break;
                case Constants.BILLING_RESPONSE_RESULT_ITEM_UNAVAILABLE:
                    showToast("Transaction cancel!");

                    break;
                case Constants.BILLING_RESPONSE_RESULT_DEVELOPER_ERROR:
                    showToast("Developer error!");

                    break;
                case Constants.BILLING_RESPONSE_RESULT_ITEM_ALREADY_OWNED:
                    showToast("This item is already purchase!");

                    break;
                case Constants.BILLING_RESPONSE_RESULT_ITEM_NOT_OWNED:
                    break;
                case Constants.BILLING_RESPONSE_RESULT_OK:
                    showToast("Successful purchase this item!");
                    break;

            }
        }

        @Override
        public void onBillingInitialized() {
            updateView();
        }
    };

    private void updateView() {
        if (bp != null && bp.isPurchased(getPackageName())) {
            ivRemoveAd.setVisibility(View.GONE);
        } else {
            ivRemoveAd.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        bp.purchase(context, getPackageName());
                    } catch (Exception ignored) {
                    }
                }
            });
            animation(ivRemoveAd);
        }
    }

    private void animation(View iv) {
        ObjectAnimator scaleXAnimator = ObjectAnimator.ofFloat(iv, "scaleX", 0.5f);
        scaleXAnimator.setRepeatMode(ValueAnimator.REVERSE);
        scaleXAnimator.setRepeatCount(ValueAnimator.INFINITE);
        scaleXAnimator.setDuration(1000);

        ObjectAnimator scaleYAnimator = ObjectAnimator.ofFloat(iv, "scaleY", 0.5f);
        scaleYAnimator.setRepeatMode(ValueAnimator.REVERSE);
        scaleYAnimator.setRepeatCount(ValueAnimator.INFINITE);
        scaleYAnimator.setDuration(1000);

        AnimatorSet set = new AnimatorSet();
        set.playTogether(scaleXAnimator, scaleYAnimator);
        set.start();
    }

    private void showToast(String s) {
        if (BuildConfig.DEBUG) {
            Toast.makeText(getApplicationContext(), s, Toast.LENGTH_LONG).show();
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);

        context = MainActivity.this;
        purchasePref = new PurchasePref(getApplicationContext());
        bp = new BillingProcessor(getApplicationContext(), getString(R.string.in_app_purchases), billingHandler);

        if (purchasePref.getItemDetail().equals("") && purchasePref.getProductId().equals("")) {
            mAdView = findViewById(R.id.adView);
            mAdView.loadAd(new AdRequest.Builder().build());
            mAdView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                    super.onAdLoaded();
                    mAdView.setVisibility(View.VISIBLE);
                }
            });
            mInterstitialAd = new InterstitialAd(this);
            mInterstitialAd.setAdUnitId(getResources().getString(R.string.interstitial_ad_id));
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
            mInterstitialAd.setAdListener(new AdListener() {
                @Override
                public void onAdClosed() {
                    super.onAdClosed();
                    mInterstitialAd.loadAd(new AdRequest.Builder().build());
                    clickListeners();
                }
            });
        }


        Init();
    }

    @Override
    public void onBackPressed() {

        if (mDialog != null && mDialog.isShowing()) {

            mDialog.dismiss();
        } else {
            ExitDialog();
        }

    }



    private void ExitDialog() {
        ImageView btnYes;
        ImageView btnNo;
        try {
            @SuppressLint("InflateParams") View view = LayoutInflater.from(MainActivity.this).inflate(R.layout.exit_dialog, null, false);
            btnYes = view.findViewById(R.id.btnYes);
            btnNo = view.findViewById(R.id.btnNo);
            mDialog = new Dialog(MainActivity.this, R.style.MaterialDialogSheet);
            mDialog.setContentView(view);
            mDialog.setCancelable(true);
            mDialog.setCanceledOnTouchOutside(false);
            if (mDialog.getWindow() != null) {
                mDialog.getWindow().setLayout(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                mDialog.getWindow().setGravity(Gravity.CENTER);
            }
            mDialog.show();
            btnYes.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mDialog.dismiss();
//                    startActivity(new Intent(MainActivity.this, Goodbye_Activity.class));
                    finish();
                }
            });
            btnNo.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    mDialog.dismiss();
                }
            });
        } catch (Exception ignored) {
        }
    }


    public void onClick(View view) {
        viewId = view.getId();
        if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
            mInterstitialAd.show();
        } else {
            clickListeners();
        }
    }

    private void clickListeners() {
        try {
            switch (viewId) {

                case R.id.iv_start:
                    startActivity(new Intent(this, MenuActivity.class));
                    break;

                case R.id.tv_share_app:
                case R.id.tv_share_app_click:
                    Intent sharingIntent = new Intent(Intent.ACTION_SEND);
                    sharingIntent.setType("text/plain");
                    sharingIntent.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.app_name));
                    sharingIntent.putExtra(Intent.EXTRA_TEXT, "https://play.google.com/store/apps/details?id=" + getPackageName());
                    if (sharingIntent.resolveActivity(getPackageManager()) != null) {
                        startActivity(Intent.createChooser(sharingIntent, "Share via"));
                    }
                    break;

                case R.id.tv_rate_us:
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName()));
                    if (i.resolveActivity(getPackageManager()) != null) {
                        startActivity(i);
                    }
                    break;

                case R.id.tv_more_apps:
                case R.id.tv_more_ap_click:
                    Intent intent_more_apps = new Intent(Intent.ACTION_VIEW);
                    intent_more_apps.setData(Uri.parse("https://play.google.com/store/apps/developer?id=Mega+Free+Apps+Developers"));
                    if (intent_more_apps.resolveActivity(getPackageManager()) != null) {
                        startActivity(intent_more_apps);
                    }
                    break;

                case R.id.tv_privacy_policy:
                case R.id.tv_privacy_policy_click:

                    startActivity(new Intent(this, PrivacyPolicyActivity.class));

                    break;
                case R.id.tv_speed_test:
                case R.id.tv_speed_test_click:

                    startActivity(new Intent(this, MainActivitySpeedometer.class));

                    break;

                case R.id.tv_exit_app:
                case R.id.tv_exit_app_click:

                    ExitDialog();
                    break;

            }
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mAdView != null) {
            mAdView.pause();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mAdView != null) {
            mAdView.resume();
            mAdView.setVisibility(View.VISIBLE);
        }
    }

    @Override
    protected void onDestroy() {
        if (mAdView != null) {
            mAdView.destroy();
        }
        if (bp != null) {
            bp.release();
        }
        super.onDestroy();
    }


}
