package com.megafreeapps.speedometer.live.camera.speed.detector.freegps.activities;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.location.Location;
import android.net.Uri;
import android.speech.RecognizerIntent;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.AppController;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.R;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.util.PurchasePref;
import com.megafreeapps.speedometer.live.camera.speed.detector.freegps.util.Utils;

import java.util.List;

public class RouteFinderActivity extends AppCompatActivity implements View.OnClickListener {

    int viewId = 0;
    InterstitialAd mInterstitialAd;
    AdView mAdView;
    boolean isFromBackPress = false;
    int PLACE_PICKER_REQUEST = 11;
    Activity context;
    Location location;
    int VOICE_REQUEST_SOURCE = 12;
    int VOICE_REQUEST_DESTINATION = 123;

    TextView tv_sources, tv_destination;
    List<String> listSource;
    List<String> listDestination;
    FusedLocationProviderClient mFusedLocationClient;

    TextView routeFinder;

    LocationCallback mLocationCallback = new LocationCallback() {
        @Override
        public void onLocationResult(LocationResult locationResult) {
            if (locationResult != null) {
                List<Location> locationList = locationResult.getLocations();
                if (locationList != null && locationList.size() > 0) {
                    //The last location in the list is the newest
                    location = locationList.get(locationList.size() - 1);
                    AppController.getAppInstance().setGlobalLocation(location);

                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_route_finder);
        context = RouteFinderActivity.this;

        Typeface font = Typeface.createFromAsset(context.getAssets(), "franklingothic.ttf");
        routeFinder = findViewById(R.id.tv_route_finder);
        routeFinder.setTypeface(font);
        startLocationUpdates();


        findViewById(R.id.btn_find_route).setOnClickListener(this);

        findViewById(R.id.destination_layout).setOnClickListener(this);
        tv_destination = findViewById(R.id.tv_destination);
        findViewById(R.id.d_mic).setOnClickListener(this);
        tv_destination.setOnClickListener(this);

        findViewById(R.id.source_layout).setOnClickListener(this);
        tv_sources = findViewById(R.id.tv_source);
        tv_sources.setOnClickListener(this);
        findViewById(R.id.s_mic).setOnClickListener(this);


        PurchasePref purchasePref = new PurchasePref(getApplicationContext());
        if (purchasePref.getItemDetail().equals("") && purchasePref.getProductId().equals("")) {
            mAdView = this.findViewById(R.id.adView);
            mAdView.loadAd(new AdRequest.Builder().build());
            mAdView.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                    super.onAdLoaded();
                    mAdView.setVisibility(View.VISIBLE);
                }
            });
            mInterstitialAd = new InterstitialAd(this);
            mInterstitialAd.setAdUnitId(getString(R.string.interstitial_ad_id));
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
            mInterstitialAd.setAdListener(new AdListener() {
                @Override
                public void onAdClosed() {
                    super.onAdClosed();

                        mInterstitialAd.loadAd(new AdRequest.Builder().build());
                        clickListeners();

                }
            });
        }

    }

    @Override
    public void onClick(View v) {

        viewId = v.getId();
        if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
            mInterstitialAd.show();
        } else {
            clickListeners();
        }

    }

    private void clickListeners() {
        switch (viewId) {


            case R.id.source_layout:
            case R.id.tv_source:
            case R.id.s_mic:
                try {
                    speechRecognizeSource();
                } catch (Exception ignored) {
                }
                break;

            case R.id.destination_layout:
            case R.id.tv_destination:
            case R.id.d_mic:
                try {
                    speechRecognizeDestination();
                } catch (Exception ignored) {
                }
                break;

            case R.id.btn_find_route:
                if (listSource == null && listDestination == null) {
                    Toast.makeText(context, "Please Select Source & Destination first!", Toast.LENGTH_SHORT).show();
                    return;
                } else if (listSource == null) {
                    Toast.makeText(context, "Please Select Source first!", Toast.LENGTH_SHORT).show();
                    return;
                } else if (listDestination == null) {
                    Toast.makeText(context, "Please Select Destination first!", Toast.LENGTH_SHORT).show();
                    return;
                }

//                    Intent mapIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + listSource.get(0)+ "," +listDestination.get(0)));
//                    mapIntent.setPackage("com.google.android.apps.maps");
//                    if (mapIntent.resolveActivity(context.getPackageManager()) != null)
//                    {
//                        context.startActivity(mapIntent);
//                    }

                Uri gmmIntentUri = Uri.parse("http://maps.google.com/maps?saddr=" + listSource.get(0) + "," + "&daddr="
                        + listDestination.get(0));
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                if (mapIntent.resolveActivity(getPackageManager()) != null) {
                    startActivity(mapIntent);
                }

                break;

        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && data != null) {
//            if (requestCode == PLACE_PICKER_REQUEST) {
//                try {
//                    Place place = PlacePicker.getPlace(context, data);
//                    Uri gmmIntentUri = Uri.parse("google.navigation:q=" + place.getName());
//                    Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
//                    mapIntent.setPackage("com.google.android.apps.maps");
//                    if (mapIntent.resolveActivity(context.getPackageManager()) != null) {
//                        startActivity(mapIntent);
//                    }
//                } catch (Exception ignored) {
//                }
//            }
//            else
            if (requestCode == VOICE_REQUEST_SOURCE) {

                try {
                    listSource = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    if (listSource != null && listSource.size() > 0) {
                        tv_sources.setText(listSource.get(0));
                    } else {
                        tv_sources.setText(null);
                    }
                } catch (Exception ignored) {
                }
            } else if (requestCode == VOICE_REQUEST_DESTINATION) {

                try {
                    listDestination = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    if (listDestination != null && listDestination.size() > 0) {
                        tv_destination.setText(listDestination.get(0));
                    } else {
                        tv_destination.setText(null);
                    }
                } catch (Exception ignored) {
                }
            }
        }
    }




    private void speechRecognizeSource() {
        try {
            if (context.getPackageManager().queryIntentActivities(new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH), 0).size() != 0) {
                Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_PROMPT, getString(R.string.txt_where_you_want_go));
                startActivityForResult(intent, VOICE_REQUEST_SOURCE);
            } else {
                AlertDialog alertDialog = new AlertDialog.Builder(context).create();
                alertDialog.setTitle(getString(R.string.txt_warning));
                alertDialog.setMessage(getString(R.string.txt_voice_recognition_not_active));
                alertDialog.setButton(Dialog.BUTTON_POSITIVE, getString(R.string.txt_ok), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                alertDialog.show();
            }
        } catch (Exception ignored) {
        }
    }

    private void speechRecognizeDestination() {
        try {
            if (context.getPackageManager().queryIntentActivities(new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH), 0).size() != 0) {
                Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_PROMPT, getString(R.string.txt_where_you_want_go));
                startActivityForResult(intent, VOICE_REQUEST_DESTINATION);
            } else {
                AlertDialog alertDialog = new AlertDialog.Builder(context).create();
                alertDialog.setTitle(getString(R.string.txt_warning));
                alertDialog.setMessage(getString(R.string.txt_voice_recognition_not_active));
                alertDialog.setButton(Dialog.BUTTON_POSITIVE, getString(R.string.txt_ok), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                alertDialog.show();
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onPause() {

        if (mAdView != null) {
            mAdView.pause();
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (mAdView != null) {
            mAdView.destroy();
        }
        stopLocationUpdates();
        super.onDestroy();
    }
    @Override
    protected void onResume() {
        super.onResume();
        if (mAdView != null) {
            mAdView.resume();
        }

    }

    public void onBackPressed() {
        super.onBackPressed();

    }

    protected void stopLocationUpdates() {
        if (mLocationCallback != null && mFusedLocationClient != null) {
            mFusedLocationClient.removeLocationUpdates(mLocationCallback);
        }

    }

    protected void startLocationUpdates() {
        try {
            LocationRequest mLocationRequest = LocationRequest.create()
                    .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                    .setInterval(Utils.UPDATE_INTERVAL)
                    .setFastestInterval(Utils.FASTEST_INTERVAL);
            mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
            if (mLocationCallback != null && mFusedLocationClient != null && mLocationRequest != null) {
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return;
                }
                mFusedLocationClient.requestLocationUpdates(
                        mLocationRequest, mLocationCallback, null);
            }
        } catch (SecurityException ignored) {
        }
    }

}
