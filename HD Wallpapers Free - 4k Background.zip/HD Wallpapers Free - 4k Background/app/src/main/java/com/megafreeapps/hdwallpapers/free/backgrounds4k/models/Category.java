package com.megafreeapps.hdwallpapers.free.backgrounds4k.models;

/**
 * Created by vicky on 3/16/16.
 */
public class Category {

    private String category;

    public Category(String category) {
        this.category = category;
    }

    public String getCategory() {
        return this.category;
    }
}
