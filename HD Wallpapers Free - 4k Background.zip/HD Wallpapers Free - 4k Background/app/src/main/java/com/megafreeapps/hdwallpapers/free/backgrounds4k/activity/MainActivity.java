package com.megafreeapps.hdwallpapers.free.backgrounds4k.activity;

import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.app.FragmentManager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import com.megafreeapps.hdwallpapers.free.backgrounds4k.R;
import com.megafreeapps.hdwallpapers.free.backgrounds4k.fragments.WallpapersFragment;
import com.megafreeapps.hdwallpapers.free.backgrounds4k.models.Category;

import org.greenrobot.eventbus.EventBus;


public class MainActivity extends AppCompatActivity {

    private InterstitialAd mInterstitialAd;
    private Resources resources;
    private Toolbar toolbar;
    private TabLayout tabLayout;
    private DrawerLayout drawerLayout;
    private String category;
    private MenuItem lastMenuItemSelected;
    private Typeface typeface;
    private AdView mAdView;
    boolean isFormBackPress = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        FirebaseApp.initializeApp(this);
//        FirebaseMessaging.getInstance().subscribeToTopic(getPackageName());
        resources = getResources();
        init();

        FragmentManager fm = getSupportFragmentManager();
        if (fm != null) {
            fm.beginTransaction().replace(R.id.frame_layout, new WallpapersFragment()).commitAllowingStateLoss();
        }

        mAdView = findViewById(R.id.adView);
        mAdView.loadAd(new AdRequest.Builder().build());
        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                mAdView.setVisibility(View.VISIBLE);
            }
        });

        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId(resources.getString(R.string.inter_ad_unit_id));
        requestNewInterstitial();
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                super.onAdClosed();
                if (isFormBackPress){
                    finish();
                }
                else {
                requestNewInterstitial();
                }
            }
        });

//        mInterstitialAd = new InterstitialAd(this);
//        mInterstitialAd.setAdUnitId(resources.getString(R.string.inter_ad_unit_id));
//        requestNewInterstitial1();
//        mInterstitialAd.setAdListener(new AdListener() {
//            @Override
//            public void onAdClosed() {
//                super.onAdClosed();
////                requestNewInterstitial1();
//                finish();
//            }
//        });

    }

    private void init() {
        initFont();
        initToolbar();
        initDrawrLayout();
        initNavView();
    }

    private void initFont() {
        typeface = Typeface.createFromAsset(getAssets(), "fonts/Pacifico.ttf");
    }

    private void initToolbar() {
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("");
        }
        TextView mTitle = toolbar.findViewById(R.id.toolbar_title);
        mTitle.setTypeface(typeface);
        mTitle.setText(resources.getString(R.string.app_name));
    }


    private void initDrawrLayout() {
        drawerLayout = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle mDrawerToggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar,
                R.string.drawer_open, R.string.drawer_close
        );
        drawerLayout.addDrawerListener(mDrawerToggle);
        mDrawerToggle.syncState();
    }

    private void initNavView() {
        NavigationView navigationView = findViewById(R.id.navigation_view);
        lastMenuItemSelected = navigationView.getMenu().getItem(0);//getting first menu item which is selected by default
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                try {
                    tabLayout.getTabAt(0).select();//select first tab to display category results
                } catch (Exception ignored) {
                }
                if (lastMenuItemSelected.getItemId() != menuItem.getItemId()) {
                    selectDrawerItem(menuItem);
                } else {
                    drawerLayout.closeDrawers();
                }
                lastMenuItemSelected = menuItem;
                return true;
            }
        });
    }

    public void selectDrawerItem(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case R.id.random:
                category = "";
                Glide.get(MainActivity.this).clearMemory();//clear cache in memory
                EventBus.getDefault().post(new Category(category));//change the category
                getSupportActionBar().setTitle("Random");
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                }
                break;
            case R.id.fashion:
                category = resources.getString(R.string.fashion_label).toLowerCase();
                Glide.get(MainActivity.this).clearMemory();//clear cache in memory
                EventBus.getDefault().post(new Category(category));//change the category
                getSupportActionBar().setTitle(resources.getString(R.string.fashion_label));
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                }
                break;
            case R.id.nature:
                category = resources.getString(R.string.nature_label).toLowerCase();
                Glide.get(MainActivity.this).clearMemory();//clear cache in memory
                EventBus.getDefault().post(new Category(category));//change the category
                getSupportActionBar().setTitle(resources.getString(R.string.nature_label));
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                }
                break;
            case R.id.backgrounds:
                category = resources.getString(R.string.backgrounds_label).toLowerCase();
                Glide.get(MainActivity.this).clearMemory();//clear cache in memory
                EventBus.getDefault().post(new Category(category));//change the category
                getSupportActionBar().setTitle(resources.getString(R.string.backgrounds_label));
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                }
                break;
            case R.id.science:
                category = resources.getString(R.string.science_label).toLowerCase();
                Glide.get(MainActivity.this).clearMemory();//clear cache in memory
                EventBus.getDefault().post(new Category(category));//change the category
                getSupportActionBar().setTitle(resources.getString(R.string.science_label));
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                }
                break;
            case R.id.education:
                category = resources.getString(R.string.education_label).toLowerCase();
                Glide.get(MainActivity.this).clearMemory();//clear cache in memory
                EventBus.getDefault().post(new Category(category));//change the category
                getSupportActionBar().setTitle(resources.getString(R.string.education_label));
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                }
                break;
            case R.id.people:
                category = resources.getString(R.string.people_label).toLowerCase();
                Glide.get(MainActivity.this).clearMemory();//clear cache in memory
                EventBus.getDefault().post(new Category(category));//change the category
                getSupportActionBar().setTitle(resources.getString(R.string.people_label));
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                }
                break;
            case R.id.feelings:
                category = resources.getString(R.string.feelings_label).toLowerCase();
                Glide.get(MainActivity.this).clearMemory();//clear cache in memory
                EventBus.getDefault().post(new Category(category));//change the category
                getSupportActionBar().setTitle(resources.getString(R.string.feelings_label));
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                }
                break;
            case R.id.religion:
                category = resources.getString(R.string.religion_label).toLowerCase();
                Glide.get(MainActivity.this).clearMemory();//clear cache in memory
                EventBus.getDefault().post(new Category(category));//change the category
                getSupportActionBar().setTitle(resources.getString(R.string.religion_label));
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                }
                break;
            case R.id.health:
                category = resources.getString(R.string.health_label).toLowerCase();
                Glide.get(MainActivity.this).clearMemory();//clear cache in memory
                EventBus.getDefault().post(new Category(category));//change the category
                getSupportActionBar().setTitle(resources.getString(R.string.health_label));
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                }
                break;
            case R.id.places:
                category = resources.getString(R.string.places_label).toLowerCase();
                Glide.get(MainActivity.this).clearMemory();//clear cache in memory
                EventBus.getDefault().post(new Category(category));//change the category
                getSupportActionBar().setTitle(resources.getString(R.string.places_label));
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                }
                break;
            case R.id.animals:
                category = resources.getString(R.string.animals_label).toLowerCase();
                Glide.get(MainActivity.this).clearMemory();//clear cache in memory
                EventBus.getDefault().post(new Category(category));//change the category
                getSupportActionBar().setTitle(resources.getString(R.string.animals_label));
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                }
                break;
            case R.id.industry:
                category = resources.getString(R.string.industry_label).toLowerCase();
                Glide.get(MainActivity.this).clearMemory();//clear cache in memory
                EventBus.getDefault().post(new Category(category));//change the category
                getSupportActionBar().setTitle(resources.getString(R.string.industry_label));
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                }
                break;
            case R.id.food:
                category = resources.getString(R.string.food_label).toLowerCase();
                Glide.get(MainActivity.this).clearMemory();//clear cache in memory
                EventBus.getDefault().post(new Category(category));//change the category
                getSupportActionBar().setTitle(resources.getString(R.string.food_label));
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                }
                break;
            case R.id.computer:
                category = resources.getString(R.string.computer_label).toLowerCase();
                Glide.get(MainActivity.this).clearMemory();//clear cache in memory
                EventBus.getDefault().post(new Category(category));//change the category
                getSupportActionBar().setTitle(resources.getString(R.string.computer_label));
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                }
                break;
            case R.id.sports:
                category = resources.getString(R.string.sports_label).toLowerCase();
                Glide.get(MainActivity.this).clearMemory();//clear cache in memory
                EventBus.getDefault().post(new Category(category));//change the category
                getSupportActionBar().setTitle(resources.getString(R.string.sports_label));
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                }
                break;
            case R.id.transportation:
                category = resources.getString(R.string.transportation_label).toLowerCase();
                Glide.get(MainActivity.this).clearMemory();//clear cache in memory
                EventBus.getDefault().post(new Category(category));//change the category
                getSupportActionBar().setTitle(resources.getString(R.string.transportation_label));
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                }
                break;
            case R.id.travel:
                category = resources.getString(R.string.travel_label).toLowerCase();
                Glide.get(MainActivity.this).clearMemory();//clear cache in memory
                EventBus.getDefault().post(new Category(category));//change the category
                getSupportActionBar().setTitle(resources.getString(R.string.travel_label));
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                }
                break;
            case R.id.buildings:
                category = resources.getString(R.string.buildings_label).toLowerCase();
                Glide.get(MainActivity.this).clearMemory();//clear cache in memory
                EventBus.getDefault().post(new Category(category));//change the category
                getSupportActionBar().setTitle(resources.getString(R.string.buildings_label));
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                }
                break;
            case R.id.business:
                category = resources.getString(R.string.business_label).toLowerCase();
                Glide.get(MainActivity.this).clearMemory();//clear cache in memory
                EventBus.getDefault().post(new Category(category));//change the category
                getSupportActionBar().setTitle(resources.getString(R.string.business_label));
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                }
                break;
            case R.id.music:
                category = resources.getString(R.string.music_label).toLowerCase();
                Glide.get(MainActivity.this).clearMemory();//clear cache in memory
                EventBus.getDefault().post(new Category(category));//change the category
                getSupportActionBar().setTitle(resources.getString(R.string.music_label));
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                }
                break;
        }

        drawerLayout.closeDrawers();
    }


    private void requestNewInterstitial() {
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
    }
//
//    private void requestNewInterstitial1() {
//        mInterstitialAd.loadAd(new AdRequest.Builder().build());
//    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mAdView != null) {
            mAdView.resume();
        }
    }

    @Override
    protected void onPause() {
        if (mAdView != null) {
            mAdView.pause();
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (mAdView != null) {
            mAdView.destroy();
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
            isFormBackPress = true;
            mInterstitialAd.show();
        } else {
            super.onBackPressed();
        }
    }
}
