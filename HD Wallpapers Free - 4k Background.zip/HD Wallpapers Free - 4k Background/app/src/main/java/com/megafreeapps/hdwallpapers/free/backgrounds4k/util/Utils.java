package com.megafreeapps.hdwallpapers.free.backgrounds4k.util;

public class Utils {
    public static String RELEASE_TOPIC_FOR_ACCOUNT = "topic_megaapps";
    public static String DEBUG_TOPIC_FOR_ACCOUNT = "test_megaapps";
}
