package com.megafreeapps.hdwallpapers.free.backgrounds4k.adapter;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.megafreeapps.hdwallpapers.free.backgrounds4k.R;
import com.megafreeapps.hdwallpapers.free.backgrounds4k.activity.WallpaperStuff;
import com.megafreeapps.hdwallpapers.free.backgrounds4k.models.Wallpaper;

import java.util.List;

/**
 * Created by vicky on 3/14/16.
 */
public class RecyclerGridAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>
{
    private List<Wallpaper> wallpaperList;
    private Context context;
    public RecyclerGridAdapter(Context context, List<Wallpaper> wallpaperList)
    {
        this.wallpaperList = wallpaperList;
        this.context = context;
    }


    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull final ViewGroup parent, int viewType)
    {
//        if (viewType == 0)
//        {
//            return new AdViewHolder(LayoutInflater.from(context).inflate(R.layout.ad_view_row, parent, false));
//        }
        return new WallpaperViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.grid_item_layout, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder, int position)
    {
//        if (holder.getItemViewType() == 0)
//        {
//        }
//        else
//        {
            WallpaperViewHolder viewHolder = (WallpaperViewHolder) holder;
            viewHolder.mTextView.setText(wallpaperList.get(position).user);
//        holder.hashId.setText(wallpaperList.get(position).getIdHash());
            Glide.with(context.getApplicationContext()).load(wallpaperList.get(position).webformatURL.replace("_640", "_340"))
                    .crossFade()
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(viewHolder.mImageView);
//        }
    }

    @Override
    public int getItemCount()
    {
        return wallpaperList.size();
    }

    @Override
    public int getItemViewType(int position)
    {
//        if (wallpaperList.get(position).user.equals("AdView") && wallpaperList.get(position).largeImageURL.equals("AdView"))
//        {
//            return 0;
//        }
        return 1;
    }



    class WallpaperViewHolder extends RecyclerView.ViewHolder
    {
        ImageView mImageView;
        TextView mTextView;
//        TextView hashId;

        WallpaperViewHolder(View v)
        {
            super(v);
            mTextView = v.findViewById(R.id.grid_item_title);
            mImageView = v.findViewById(R.id.grid_item_image);
//            hashId = v.findViewById(R.id.hash_id);
            itemView.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View v)
                {
                        WallpaperStuff.sData = wallpaperList.get(getAdapterPosition());
                        Intent intent = new Intent(context, WallpaperStuff.class);
                        context.startActivity(intent);

                }
            });
        }
    }

}