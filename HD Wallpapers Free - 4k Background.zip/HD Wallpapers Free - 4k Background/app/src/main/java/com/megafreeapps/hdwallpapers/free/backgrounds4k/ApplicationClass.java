package com.megafreeapps.hdwallpapers.free.backgrounds4k;

import android.content.Context;
import android.support.multidex.MultiDex;
import android.support.multidex.MultiDexApplication;

import com.google.android.gms.ads.MobileAds;

import java.util.Locale;

public class ApplicationClass extends MultiDexApplication {
    private static ApplicationClass applicationClass;


    public ApplicationClass() {
        applicationClass = this;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        MobileAds.initialize(this, getString(R.string.app_id));
        MultiDex.install(this);
    }


}

