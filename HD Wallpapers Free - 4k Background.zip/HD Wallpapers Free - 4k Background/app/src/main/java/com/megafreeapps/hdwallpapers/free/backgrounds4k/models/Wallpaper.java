package com.megafreeapps.hdwallpapers.free.backgrounds4k.models;

public class Wallpaper
{
    public String fullHDURL, webformatURL, user, largeImageURL;

    public Wallpaper(String fullHDURL, String webformatURL, String user, String largeImageURL)
    {
        this.fullHDURL = fullHDURL;
        this.webformatURL = webformatURL;
        this.user = user;
        this.largeImageURL = largeImageURL;
    }
}
