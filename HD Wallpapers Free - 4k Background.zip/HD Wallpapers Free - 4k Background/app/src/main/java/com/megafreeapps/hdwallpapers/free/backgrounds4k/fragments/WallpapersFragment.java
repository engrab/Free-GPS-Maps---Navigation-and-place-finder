package com.megafreeapps.hdwallpapers.free.backgrounds4k.fragments;


import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;
import com.megafreeapps.hdwallpapers.free.backgrounds4k.R;
import com.megafreeapps.hdwallpapers.free.backgrounds4k.adapter.RecyclerGridAdapter;
import com.megafreeapps.hdwallpapers.free.backgrounds4k.models.Category;
import com.megafreeapps.hdwallpapers.free.backgrounds4k.models.Wallpaper;
import com.megafreeapps.hdwallpapers.free.backgrounds4k.util.ProgressHUD;
import com.megafreeapps.hdwallpapers.free.backgrounds4k.util.SpacesItemDecoration;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class WallpapersFragment extends BaseFragment
{
    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private GridLayoutManager mLayoutManager;
    private int pageNumber = 1;
    private String category = "";
    private List<Wallpaper> hitList;
    private List<Wallpaper> hitListWithAds;
    private boolean canLoad = true;
    private int pastVisiblesItems, visibleItemCount, totalItemCount;
    private ProgressHUD mProgressHUD;
    private Boolean reachedEnd = false;
    private LinearLayout errorLayout;

    public WallpapersFragment()
    {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState)
    {
        View view = inflater.inflate(R.layout.fragment_wallpapers, container, false);
        Init(view);
        return view;
    }

    private void Init(View view)
    {
        errorLayout = view.findViewById(R.id.error_layout);
        view.findViewById(R.id.retry_button).setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                mProgressHUD = ProgressHUD.show(getActivity(), "Loading", true, false, null);
                errorLayout.setVisibility(View.GONE);
                makeNetworkRequest();
            }
        });
        mRecyclerView = view.findViewById(R.id.my_recycler_view);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.getItemAnimator().setChangeDuration(0);
        mLayoutManager = new GridLayoutManager(context, 2);
        mLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup()
        {
            @Override
            public int getSpanSize(int position)
            {
                return mAdapter.getItemViewType(position) == 1 ? 1 : 2;
            }
        });
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.addItemDecoration(new SpacesItemDecoration(getResources().getDimensionPixelSize(R.dimen.card_insets)));
        mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener()
        {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy)
            {
                if (dy > 0) //check for scroll down
                {
                    visibleItemCount = mLayoutManager.getChildCount();
                    totalItemCount = mLayoutManager.getItemCount();
                    pastVisiblesItems = mLayoutManager.findFirstVisibleItemPosition();

                    if (canLoad)
                    {
                        if ((visibleItemCount + pastVisiblesItems) >= totalItemCount)
                        {//if reached to end of grid
                            canLoad = false;
                            if (!reachedEnd)
                            {
                                makeNetworkRequest();
                            }
                        }
                    }
                }
            }
        });

        makeNetworkRequest();
        mProgressHUD = ProgressHUD.show(getActivity(), "Loading", true, false, null);
    }

    private void makeNetworkRequest()
    {
        try
        {
            Ion.with(context).load("https://pixabay.com/api/?key=9184781-ef086c186e975ad71b0b5b65b&page=" + pageNumber + "&response_group" +
                    "=high_resolution" +
                    "&category=" + category + "&safesearch=true").asJsonObject().setCallback(new FutureCallback<JsonObject>()
            {
                @Override
                public void onCompleted(Exception e, JsonObject result)
                {
                    try
                    {
                        if (result != null && result.size() > 0 && e == null)
                        {
                            JsonArray jsonArray = result.get("hits").isJsonNull() ? null : result.get("hits").getAsJsonArray();
                            if (jsonArray != null && jsonArray.size() > 0)
                            {
                                mRecyclerView.setVisibility(View.VISIBLE);
                                Gson gson = new Gson();
                                List<Wallpaper> list = new LinkedList<>(Arrays.asList(gson.fromJson(jsonArray.toString(), Wallpaper[].class)));
                                if (list != null && list.size() > 0)
                                {
                                    if (pageNumber == 1)
                                    {
                                        hitList = new ArrayList<>();
                                        hitListWithAds = new ArrayList<>();
                                        hitList.addAll(list);
                                        hitListWithAds.addAll(list);
//                                        addNativeAds();
                                        mAdapter = new RecyclerGridAdapter(getActivity(), hitListWithAds);
                                        mRecyclerView.setAdapter(mAdapter);
                                        mRecyclerView.scrollToPosition(0);// scroll to top after selecting a category
                                    }
                                    else
                                    {
                                        hitList.addAll(list);
                                        hitListWithAds.clear();
                                        hitListWithAds.addAll(hitList);
//                                        addNativeAds();
                                        mAdapter.notifyDataSetChanged();
                                    }
                                }
                                ++pageNumber;
                                canLoad = true;
                            }
                        }
                        else
                        {
                            if (pageNumber == 27)
                            {
                                reachedEnd = true;
                            }
                            else
                            {
                                mRecyclerView.setVisibility(View.GONE);
                                errorLayout.setVisibility(View.VISIBLE);
                            }
                            canLoad = true;
                        }
                        mProgressHUD.dismiss();
                    }
                    catch (Exception e1)
                    {
                        mRecyclerView.setVisibility(View.GONE);
                        errorLayout.setVisibility(View.VISIBLE);
                        canLoad = true;
                        mProgressHUD.dismiss();
                    }
                }
            });
        }
        catch (Exception e)
        {
            mRecyclerView.setVisibility(View.GONE);
            errorLayout.setVisibility(View.VISIBLE);
            canLoad = true;
            mProgressHUD.dismiss();
        }
    }

    public void addNativeAds()
    {
        String position = "";
        for (int i = 0; i < hitList.size(); i++)
        {
            if (i != 0 && i % 10 == 0)
            {
                position = i + "";
                position = position.substring(0, 1);
                hitListWithAds.add(Integer.valueOf(position + (Integer.valueOf(position) - 1)), new Wallpaper("AdView",
                        "AdView", "AdView", "AdView"));
            }
        }
    }


    /**
     * Called from MainActivity when category is changed from navigation drawer
     *
     * @param category
     */
    @Subscribe
    public void onCategory(Category category)
    {
        //Toast.makeText(getActivity(), category.getCategory(), Toast.LENGTH_SHORT).show();
        this.category = category.getCategory();
        if (hitList != null)
        {
            hitList.clear();//clearing old entries form the list
            hitListWithAds.clear();//clearing old entries form the list
            mAdapter.notifyDataSetChanged();// notifying the adapter about change in dataset
        }
        errorLayout.setVisibility(View.GONE);//hide the errorLayout if it is visible
        mRecyclerView.setVisibility(View.VISIBLE);//show the gridView
        pageNumber = 1;//resetting page to 1
        reachedEnd = false;// for infinite scrolling
        makeNetworkRequest();//fresh network request
        mProgressHUD = ProgressHUD.show(getActivity(), "Loading", true, false, null);
    }


    @Override
    public void onResume()
    {
        super.onResume();
        EventBus.getDefault().register(this); // register EventBus
    }


    public void onPause()
    {
        super.onPause();
        EventBus.getDefault().unregister(this); // unregister EventBus
    }

}
