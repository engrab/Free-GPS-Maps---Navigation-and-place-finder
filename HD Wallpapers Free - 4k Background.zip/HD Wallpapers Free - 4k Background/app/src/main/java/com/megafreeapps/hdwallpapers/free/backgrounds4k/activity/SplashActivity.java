package com.megafreeapps.hdwallpapers.free.backgrounds4k.activity;


import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.Window;
import android.view.WindowManager;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.megafreeapps.hdwallpapers.free.backgrounds4k.R;


public class SplashActivity extends AppCompatActivity
{

    private InterstitialAd mInterstitialAd;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        // Remove the Title Bar
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash);
        MobileAds.initialize(this, getString(R.string.app_id));
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.inter_ad_unit_id));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                startActivity(new Intent(SplashActivity.this, StartActivity.class));
                finish();
            }
        });
        new Handler().postDelayed(new Runnable()
        {

            @Override
            public void run()
            {
                if (mInterstitialAd != null && mInterstitialAd.isLoaded()){
                    mInterstitialAd.show();
                }
                else {

                    startActivity(new Intent(SplashActivity.this, StartActivity.class));
                    finish();
                }
            }
        }, 3000);
    }
}

